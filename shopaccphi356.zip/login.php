<?php
/*
 * login.php 
 * Chuc nang: đăng nhập bằng facebook
 */




// Require database & thông tin chung
require_once 'core/init.php';

$fb = new Facebook\Facebook([
'app_id' => $app_id,
'app_secret' => $app_secret,
'default_graph_version' => 'v2.4',
'default_access_token' => isset($_SESSION['facebook_access_token']) ? $_SESSION['facebook_access_token'] : $default_access_token
]);

$helper = $fb->getRedirectLoginHelper();

try {
$accessToken = $helper->getAccessToken('https://minhphi365.com/login.php');
} catch(Facebook\Exceptions\FacebookResponseException $e) {
  // When Graph returns an error
  //echo 'Graph returned an error: ' . $e->getMessage();
} catch(Facebook\Exceptions\FacebookSDKException $e) {
  // When validation fails or other local issues
  //echo 'Facebook SDK returned an error: ' . $e->getMessage();
}


if (isset($accessToken)) {// đã lấy được token, đăng nhập thành công

	$_SESSION['facebook_access_token'] = (string) $accessToken;// lưu token vào session
	// Lưu session
	$response = $fb->get('/me?fields=id,name,email', $accessToken);
	//$getname = $response->getGraphUser()['name'];
	$name = trim(addslashes(htmlspecialchars($response->getGraphUser()['name'])));
	$email = $response->getGraphUser()['email'];
	$iduser = $response->getGraphUser()['id'];


	//kiểm tra người dùng có trong hệ thống
	if ($db->num_rows("SELECT username FROM accounts WHERE username = '$iduser'") < 1) {
	// Thực thi tạo người dùng
	$db->query("INSERT INTO `accounts` (username,taikhoan,name,email,cash,admin,block,time) VALUES ('$iduser','$iduser','$name','$email',0,0,0,'$date_current')");
	}
	$session->send($iduser);//lưu session id fb
	$db->close(); // Giải phóng

} elseif ($helper->getError()) {
  // The user denied the request
}

new Redirect($_DOMAIN); // về trang chủ



?>