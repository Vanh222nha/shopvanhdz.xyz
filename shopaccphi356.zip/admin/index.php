<?php
// Require database
require_once '../core/init.php';
// Require header
require_once '../includes/headeradmin.php';

$card_cham = $db->fetch_row("SELECT COUNT(*) FROM history_card where `status` ='0' LIMIT 1"); // Card chậm chưa xử lý
$order_card = $db->fetch_row("SELECT COUNT(*) FROM order_card where `status` ='0' LIMIT 1"); // Mua card chưa xử lý
$atm = $db->fetch_row("SELECT COUNT(*) FROM history_atm where `status` ='0' LIMIT 1"); // ATM chưa xử lý

// Nếu đăng nhập
if ($user) {
      // Nếu tài khoản không phải là admin
      if ($data_user['admin'] == 0) {
            new Redirect($_DOMAIN); // Trở về trang index
            exit;
      }
      echo'<div class="content content-boxed"><div class="col-sm-5 col-sm-push-7 col-lg-4 col-lg-push-8">';
      require_once 'templates/sidebar.php'; 
      echo'</div><div class="col-sm-7 col-sm-pull-5 col-lg-8 col-lg-pull-4">';
      $act = isset($_GET['act']) ? $_GET['act'] : '';
      switch ($act) {
      case 'edit_card':
            require_once 'templates/edit_card.php'; 
            break;
      case 'card':
            require_once 'templates/card.php'; 
            break;
      case 'edit_order_card':
            require_once 'templates/edit_order_card.php'; 
            break;
      case 'order_card':
            require_once 'templates/order_card.php'; 
            break;
      case 'setting':
            require_once 'templates/settings.php'; 
            break;
      case 'random':
            require_once 'templates/random.php'; 
            break;
      case 'atm':
            require_once 'templates/atm.php'; 
            break;
      case 'bank':
            require_once 'templates/bank.php'; 
            break;
      case 'wheel':
            require_once 'templates/wheel.php'; 
            break;            
      case 'post':
            require_once 'templates/post.php'; 
            break;
      case 'list':
            require_once 'templates/list.php'; 
            break;   
     case 'viewcard':
            require_once 'templates/viewcard.php'; 
            break;  
      case 'edit_acc':
            require_once 'templates/edit_acc.php'; 
            break;      
      case 'log':
            require_once 'templates/log.php'; 
            break;  
      case 'member':
            require_once 'templates/member.php'; 
            break; 
      case 'edit':
            require_once 'templates/edit.php'; 
            break; 
      default:
            require_once 'templates/main.php'; 
            break;
      }
      echo'</div></div>';
} else {
      new Redirect($_DOMAIN); // Trở về trang index
}

// Require footer
require_once '../includes/footeradmin.php';
 
?>