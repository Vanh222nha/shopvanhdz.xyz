<div class="block block-opt-refresh-icon6">
<div class="block-header">
<h3 class="block-title"><i class="fa fa-fw fa-briefcase"></i> Công Cụ</h3>
</div>
<div class="block-content">
<ul class="list list-simple list-li-clearfix">
    <li>
<a class="item item-rounded pull-left push-10-r bg-info" href="/">
<i class="fa fa-home"></i>
</a>
<h5 class="push-10-t">Về Shop</h5>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-info" href="/admin">
<i class="si si-basket text-white-op"></i>
</a>
<h5 class="push-10-t">Hệ Thống</h5>
<div class="font-s13">Thống Kê</div>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-info" href="?act=setting">
<i class="si si-settings text-white-op"></i>
</a>
<h5 class="push-10-t">Cài đặt chung</h5>
<div class="font-s13">Thiết lập lại tiêu đề, bảo trì trang web</div>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-amethyst" href="?act=post">
<i class="si si-pencil text-white-op"></i>
</a>
<h5 class="push-10-t">Đăng bán</h5>
<div class="font-s13">Đăng tài khoản cần bán lên trang chủ</div>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-amethyst" href="?act=random">
<i class="si si-pencil text-white-op"></i>
</a>
<h5 class="push-10-t">Acc Random</h5>
<div class="font-s13">Đăng tài khoản random lên trang chủ</div>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-amethyst" href="?act=wheel">
<i class="si si-pencil text-white-op"></i>
</a>
<h5 class="push-10-t">Quà quay số</h5>
<div class="font-s13">Đăng tài khoản vào phần thường quay số</div>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-warning" href="?act=list">
<i class="fa fa-tags text-white-op"></i>
</a>
<h5 class="push-10-t">Tài khoản</h5>
<div class="font-s13">Danh sách tài khoản đang bán</div>
</li>

<li>
<a class="item item-rounded pull-left push-10-r bg-danger" href="?act=log">
<i class="si si-basket text-white-op"></i>
</a>
<h5 class="push-10-t">Giao dịch</h5>
<div class="font-s13">Tất cả giao dịch của thành viên</div>
</li>

<li>
<a class="item item-rounded pull-left push-10-r bg-danger" href="?act=atm">
<i class="fa fa-bank"></i>
</a>
<h5 class="push-10-t">ATM</h5></h5>
<div class="font-s13"><?php echo $atm;?> yêu cầu xử lý</div>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-danger" href="?act=order_card">
<i class="si si-wallet"></i>
</a>
<h5 class="push-10-t">Mua thẻ chậm</h5></h5>
<div class="font-s13"><?php echo $order_card;?> yêu cầu xử lý</div>
</li>
<li>
<a class="item item-rounded pull-left push-10-r bg-danger" href="?act=card">
<i class="si si-wallet"></i>
</a>
<h5 class="push-10-t">Gạch thẻ chậm</h5></h5>
<div class="font-s13"><?php echo $card_cham;?> yêu cầu xử lý</div>
</li>

<li>
<a class="item item-rounded pull-left push-10-r bg-success" href="?act=member">
<i class="si si-users text-white-op"></i>
</a>
<h5 class="push-10-t">Thành viên</h5>
<div class="font-s13">Quản lý, chỉnh sửa thông tin thành viên</div>
</li>

</ul>
</div>
</div>
