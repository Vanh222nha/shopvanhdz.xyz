<form act="" method="post">
  <div class="form-group">
    <label for="u">TK:</label>
    <input type="text" class="form-control" name="u">
  </div>
  <div class="form-group">
    <label for="p">MK:</label>
    <input type="password" class="form-control" name="p">
  </div>
  <button type="submit" class="btn btn-default" name="add">Thêm</button>
</form><br/>
<table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>TK</th>
                                    <th>MK</th>
                                    <th></th>
                                </tr></thead>
                        <tbody>
<?php 
if(isset($_GET['del'])):
$db->query("DELETE FROM wheel_acc WHERE id ='".$_GET['del']."'");
endif;
    
if(isset($_POST['add'])):
    $u = $_POST['u'];
    $p = $_POST['p'];
$db->query("INSERT INTO `wheel_acc` (username,pass,date) VALUES ('$u','$p','".time()."')");
endif;
$i=1;
$sql_get_list_buy = "SELECT * FROM `wheel_acc` WHERE status != '1' ORDER BY `date` DESC LIMIT 100";
foreach ($db->fetch_assoc($sql_get_list_buy, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td><?php echo $data['username']; ?></td>
                                    <td><?php echo $data['pass']; ?></td>
                                    <td><a href="?act=wheel&del=<?php echo $data['id']; ?>">X</a></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>