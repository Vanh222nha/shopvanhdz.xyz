<?php

$get_info_card = new Info;
$input = new Input;
$id = (int)$input->input_get("id");
$sql_get = "SELECT * FROM order_card where `id` = {$id} LIMIT 1";
if ($db->num_rows($sql_get)) {
$data = $db->fetch_assoc($sql_get, 1);

}else{
new Redirect("/admin/?act=order_card"); 
}


?>
<div class="block block-themed">
<div class="block-header bg-info">
<h3 class="block-title">Xứ lý thẻ cào</h3>
</div>
<div class="block-content">
<form class="form-horizontal push-5-t" id="edit" novalidate="novalidate">


<div class="form-group">
<div class="col-xs-6">
<label for="username">Username</label>
<input class="form-control" type="text" value="<?php echo $data['username']; ?>" disabled>
<input type="hidden" name="id" value="<?php echo $id; ?>">
<input type="hidden" name="username" value="<?php echo $data['username']; ?>">
</div>
<div class="col-xs-6">
<label for="admin">Trạng thái</label>
<input class="form-control" type="text" value="<?php echo $get_info_card->get_order_card($data["status"]); ?>" disabled>
</div>
</div>


<div class="form-group">
<div class="col-xs-6">
<label for="username">Loại thẻ</label>
<input class="form-control" type="text" value="<?php echo $get_info_card->get_string_card($data["type_card"]); ?>" disabled>
</div>
<div class="col-xs-6">
<label for="admin">Mệnh giá</label>
<input class="form-control" type="text" value="<?php echo $data['count_card']/1000; ?>K" disabled>
</div>
</div>

<div class="form-group">
<div class="col-xs-6">
<label for="mathe">Mã thẻ</label>
<input class="form-control" type="text" name="pin" placeholder="<?php echo $data['mathe']; ?>" value="<?php echo $data['mathe']; ?>">
</div>
<div class="col-xs-6">
<label for="seri">Serial</label>
<input class="form-control" type="text" name="seri" placeholder="<?php echo $data['seri']; ?>" value="<?php echo $data['seri']; ?>">
</div>
</div>

<?php if($data['status'] =='0'){ ?>
<div class="form-group">
<label class="col-xs-12" for="email">Hành động</label>
<div class="col-xs-12">
<div class="col-xs-6">
<label for="1"><input type="radio" id="1" name="status" value="1">Thành công</label><br/>
<label for="2"><input type="radio" id="2" name="status" value="2">Hết thẻ. Hoàn tiền</label>
</div>
<div class="col-xs-6">
<label for="3"><input type="radio" id="3" name="status" value="3">Bảo trì. Hoàn tiền</label>
</div>
</div>
</div>





<div class="form-group">
<div class="col-xs-12">
<button class="btn btn-sm btn-success" type="submit">Lưu lại</button>
</div>
</div>
<?php }else{?>
<center style="color:green;">Giao dịch đã được xử lý</center>
<?php }?>
</form>
</div>
</div>
</div>

<script>
  $(document).ready(function () {
      $("#edit").validate({
          submitHandler: function (e) {
          $('button[type="submit"]').html("Đang lưu...");
          $.post("/assets/ajax/edit_order_card.php", $('#edit').serialize(), function(data) {
              $('button[type="submit"]').html("Lưu lại");
              swal(data.title, data.msg, data.status);
              if(data.code == 0){
              setTimeout(function () {
              window.location.href = "/admin/?act=order_card";
              }, 2000);}
          }, "json");
              return false;
          }
      });
  });
</script>