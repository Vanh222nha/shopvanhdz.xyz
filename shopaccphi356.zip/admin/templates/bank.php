<?php


$input = new Input;
$id = (int)$input->input_get("id");
$sql_get = "SELECT * FROM history_atm where `id` = {$id} LIMIT 1";
if ($db->num_rows($sql_get)) {
$data = $db->fetch_assoc($sql_get, 1);
}else{
new Redirect("/admin/?act=atm"); 
}


?>
<div class="block block-themed">
<div class="block-header bg-info">
<h3 class="block-title">Thông tin rút tiền</h3>
</div>
<div class="block-content">
<form class="form-horizontal push-5-t" id="edit" novalidate="novalidate">


<div class="form-group">
<div class="col-xs-6">
<label for="username">Username</label>
<input class="form-control" type="text" value="<?php echo $data['username']; ?>" disabled>
<input class="form-control" type="hidden" id="username" name="username" value="<?php echo $data['username']; ?>">
<input type="hidden" name="id" value="<?php echo $id; ?>">
<input type="hidden" name="cash" value="<?php echo $data['cash']; ?>">
</div>
<div class="col-xs-6">
<label for="admin">Trạng thái</label>
<select class="form-control border-input" id="status" name="status">
        <option value="0" <?php echo ($data['status']=='0') ? 'selected':''; ?>>Chưa xử lý</option>
        <option value="1" <?php echo ($data['status'] == '1') ? 'selected':''; ?>>Hoàn Thành</option>
        <option value="2" <?php echo ($data['status'] == '2') ? 'selected':''; ?>>Hủy giao dịch</option>
    </select>
</div>
</div>

<div class="form-group">
<label class="col-xs-12" for="email">Ngân hàng</label>
<div class="col-xs-12">
<input class="form-control" type="text" value="<?php echo $data['nganhang']; ?>">
</div>
</div>

<div class="form-group">
<label class="col-xs-12" for="cash">Chủ tài khoản</label>
<div class="col-xs-12">
<input class="form-control" type="text" value="<?php echo $data['chutk']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="cash">Số tài khoản</label>
<div class="col-xs-12">
<input class="form-control" type="text"  value="<?php echo $data['sotk']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="cash">Số tiền chuyển(đã tính phí)</label>
<div class="col-xs-12">
<input class="form-control" type="text"  value="<?php echo $data['cash_nhan']; ?>">
</div>
</div>
<div class="form-group">
<label class="col-xs-12" for="cash">Ghi chú</label>
<div class="col-xs-12">
<input class="form-control" type="text"  value="<?php echo $data['note']; ?>" disabled>
</div>
</div>
<div class="form-group">
<div class="col-xs-12">
<?php if($data['status'] =='0'){ ?>    
<button class="btn btn-sm btn-success" type="submit">Lưu lại</button>
<?php }elseif($data['status'] =='2'){?>
<center style="color:red;">Giao dịch đã hủy</center>
<?php }else{?>
<center style="color:green;">Giao dịch hoàn thành</center>
<?php }?>
</div>
</div>
</form>
</div>
</div>
</div>

<script>
  $(document).ready(function () {
      $("#edit").validate({
          submitHandler: function (e) {
          $('button[type="submit"]').html("Đang lưu...");
          $.post("/assets/ajax/bank.php", $('#edit').serialize(), function(data) {
              $('button[type="submit"]').html("Lưu lại");
              swal(data.title, data.msg, data.status);
              setTimeout(function () {
              window.location.href = "/admin/?act=atm";
              }, 2000);
          }, "json");
              return false;
          }
      });
  });
</script>