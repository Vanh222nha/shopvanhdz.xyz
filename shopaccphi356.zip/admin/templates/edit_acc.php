<?php

$select = new Info;
$input = new Input;
$id = (int)$input->input_get("id");
$sql_get = "SELECT * FROM posts where `id_post` = {$id} LIMIT 1";
if ($db->num_rows($sql_get)) {
$data = $db->fetch_assoc($sql_get, 1);
}else{
new Redirect("/admin/?act=list"); 
}


?>
<div class="block block-themed">
<div class="block-header bg-info">
<h3 class="block-title">Chỉnh sửa - Mã số <?php echo $data['id_post']; ?> - <?php echo $data['type_account']; ?></h3>
</div>
<div class="block-content">
    
<form id="data" method="post" enctype="multipart/form-data" class="form-horizontal push-5-t" novalidate="novalidate" >

<div class="form-group">
<div class="col-xs-4">
<label for="username">Tên đăng nhập</label>
<input class="form-control" type="text" id="username" name="username" placeholder="Tên đăng nhập Garena" value="<?php echo $data['username']; ?>">
</div>
<div class="col-xs-4">
<label for="password">Mật khẩu</label>
<input class="form-control" type="password" id="password" name="password" placeholder="*****" value="<?php echo $data['password']; ?>">
</div>
<div class="col-xs-4">
<label for="email">Email</label>
<input class="form-control" type="text" id="email" name="email" placeholder="Email" value="<?php echo $data['email']; ?>">
</div>
<div class="col-xs-4">
<label for="chbm">Câu Hỏi Bảo Mật</label>
<input class="form-control" type="text" id="chbm" name="chbm" placeholder="Câu Hỏi Bảo Mật" value="<?php echo $data['chbm']; ?>">
</div>
<div class="col-xs-4">
<label for="cmnd">Chứng Minh Nhân Dân</label>
<input class="form-control" type="number" id="cmnd" name="cmnd" placeholder="123456789" value="<?php echo $data['cmnd']; ?>">
</div>
<div class="col-xs-4">
<label for="price">Giá tiền</label>
<input class="currency form-control" type="number" id="price" name="price"  value="<?php echo $data['price']; ?>">
</div>
</div>

<div class="form-group">
<?php if($data["type_account"]!='FIFA'): ?>    
<div class="col-xs-4">
<label for="skins_count">Số skin</label>
<input class="form-control" type="number" id="skins_count" name="skins_count" placeholder=""  value="<?php echo $data['skins_count']; ?>">
</div>
<div class="col-xs-4">
<label for="champs_count">Số tướng</label>
<input class="form-control" type="champs_count" id="champs_count" name="champs_count" placeholder=""  value="<?php echo $data['champs_count']; ?>">
</div>
<?php else: ?>
<div class="col-xs-4">
<label for="ep">EP</label>
<input class="form-control" type="number" id="ep" name="ep" placeholder="" value="<?php echo $data['ff_exp']; ?>">
</div>
<div class="col-xs-4">
<label for="gtdh">Giá Trị Đội</label>
<input class="form-control" type="gtdh" id="gtdh" name="gtdh" placeholder="" value="<?php echo $data['ff_value']; ?>">
</div>
<?php endif; ?>

<div class="col-xs-4">
<label for="price_atm">Giá tền ATM</label>
<input class="currency form-control" type="number" id="price_atm" name="price_atm"  value="<?php echo $data['price_atm']; ?>">
</div>
</div>

<?php if($data["type_account"]!='FIFA'): ?>
<div class="form-group">
<div class="col-xs-4"><label for="rank">Rank</label>
<select class="form-control" name="rank">
<?php
for ($i = 0; $i < 29; $i++){
    if($i == $data['rank']):
    echo '<option value="'.$i.'" selected>'.$select->get_string_rank($i).'</option>';
    else:
    echo '<option value="'.$i.'">'.$select->get_string_rank($i).'</option>';
    endif;        
}
?>
</select></div>
<div class="col-xs-4"><label for="frame">Khung</label>
<select class="form-control" name="frame">
<?php
for ($i = 0; $i < 7; $i++){
    if($i == $data['frame']):
    echo '<option value="'.$i.'" selected>'.$select->get_string_frame($i).'</option>';
    else:
    echo '<option value="'.$i.'">'.$select->get_string_rank($i).'</option>';
    endif;        
    
}
?>
</select></div>

<div class="col-xs-4">
<label for="ip_count"><?php echo ($data["type_account"]=='Liên Minh Huyền Thoại')? 'IP' : 'Vàng'; ?> hiện có</label>
<input class="currency form-control" type="number" id="ip_count" name="ip_count" value="<?php echo $data['ip_count']; ?>">

</div>
</div>
<?php endif; ?>

<div class="form-group">
<label class="col-xs-12" for="thumb">Ảnh minh họa <b data-toggle="tooltip" data-placement="right" title="Ảnh hiện ở trang chủ"><i class="fa fa-question-circle"></i></b></label>
<div class="col-xs-12">
<input class="currency form-control" type="file" name="thumb" />
</div>
</div>

<?php if($data["type_account"]!='FIFA'): ?>
<div class="form-group">
<label class="col-xs-12" for="gem">Ảnh bảng ngọc <b data-toggle="tooltip" data-placement="right" title="Mỗi ảnh sẽ là một bảng ngọc, có thể up nhiều ảnh"><i class="fa fa-question-circle"></i></b></label>
<div class="col-xs-12">
<input class="currency form-control" type="file" name="gem[]" multiple />
</div>
</div>

<div class="form-group">
<label class="col-xs-12" for="champs">Ảnh tướng <b data-toggle="tooltip" data-placement="right" title="Ảnh hiện trong mục ảnh thông tin tài khoản, có thể up nhiều ảnh"><i class="fa fa-question-circle"></i></b></label>
<div class="col-xs-12">
<input class="currency form-control" type="file" name="champs[]" multiple />
</div>
</div>
<?php else: ?>
<div class="form-group">
<label class="col-xs-12" for="champs">Ảnh thông tin <b data-toggle="tooltip" data-placement="right" title="Ảnh hiện trong mục ảnh thông tin tài khoản, có thể up nhiều ảnh"><i class="fa fa-question-circle"></i></b></label>
<div class="col-xs-12">
<input class="currency form-control" type="file" name="info[]" multiple />
</div>
</div>
<?php endif; ?>


<?php if($data["type_account"]=='Liên Minh Huyền Thoại'): ?>
<div class="form-group">
<label class="col-xs-12" for="skins">Nhập danh sách tên Skins <b data-toggle="tooltip" data-placement="right" title="Enter xuống dòng"><i class="fa fa-question-circle"></i></b></label>
<div class="col-xs-12">
<textarea class="form-control" id="skins" name="skins" rows="4" placeholder="Nhập danh sách tên vào đây, mỗi tên cách nhau bởi dấu phẩy để xuống dòng" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"><?php echo $data['skins']; ?></textarea>
</div>
</div>

<div class="form-group">
<label class="col-xs-12" for="champs">Nhập danh sách tên Champs <b data-toggle="tooltip" data-placement="right" title="Enter xuống dòng"><i class="fa fa-question-circle"></i></b></label>
<div class="col-xs-12">
<textarea class="form-control" id="champs" name="champs" rows="4" placeholder="Nhập danh sách tên vào đây, mỗi tên cách nhau bởi dấu phẩy để xuống dòng" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"><?php echo $data['champs']; ?></textarea>
</div>
</div>
<?php endif; ?>

<div class="form-group">
<label class="col-xs-12" for="note">Ghi chú <b data-toggle="tooltip" data-placement="right" title="Hiển thị ở trang chủ khi để chuột vào"><i class="fa fa-question-circle"></i></b></label>
<div class="col-xs-12">
<textarea class="form-control" id="note" name="note" rows="4" placeholder="Enter để xuống dòng" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false"><?php echo $data['note']; ?></textarea>
</div>
</div>

<div class="form-group">
<label class="col-xs-12" for="type_post">Loại</label>
<div class="col-xs-12">
<label class="css-input css-radio css-radio-warning push-10-r"><input type="radio" name="type_post" value="0" <?php echo ($data['type_post'] == 0) ? 'checked' : ''; ?>><span></span> Bình thường</label> 
<label class="css-input css-radio css-radio-warning"><input type="radio" name="type_post" value="1" <?php echo ($data['type_post'] == 1) ? 'checked' : ''; ?>><span></span> Acc ngon</label> 
<label class="css-input css-radio css-radio-warning"><input type="radio" name="type_post" value="2" <?php echo ($data['type_post'] == 2) ? 'checked' : ''; ?>><span></span> Acc vip</label>
<label class="css-input css-radio css-radio-warning"><input type="radio" name="type_post" value="3" <?php echo ($data['type_post'] == 3) ? 'checked' : ''; ?>><span></span> Quảng cáo</label>
</div>
</div>

<input type="hidden" name="id" value="<?php echo $id; ?>">
<input type="hidden" name="type_account" value="<?php echo $data['type_account']; ?>">

<div class="form-group">
<div class="col-xs-12">
<button class="btn btn-sm btn-success" type="submit" id="submit">Sửa</button>
</div>
</div>
</form>

</div>
</div>

<script>
$("form#data").submit(function(){

    var formData = new FormData($(this)[0]);

    $("#submit").prop('disabled', true);
    $.ajax({
        url: '/assets/ajax/edit_acc.php',
        type: 'POST',
        data: formData,
        async: false,
        dataType: 'json',
        success: function (data) {
        swal(data.title, data.msg, data.status);
        setTimeout(function () {
        window.location.href = "/admin/?act=edit_acc";
        }, 3000);
        },
        cache: false,
        contentType: false,
        processData: false
    });

    
    return false;
});
</script>