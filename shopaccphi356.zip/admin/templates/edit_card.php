<?php

$get_info_card = new Info;
$input = new Input;
$id = (int)$input->input_get("id");
$sql_get = "SELECT * FROM history_card where `id` = {$id} LIMIT 1";
if ($db->num_rows($sql_get)) {
$data = $db->fetch_assoc($sql_get, 1);

//Số tiền nhận được nếu thẻ đúng
if($data['type_card'] == '1'){
    $cash_nhan = $data['count_card']*$data_site['ckc_viettel']/100;}
elseif($data['type_card'] == '2'){
    $cash_nhan = $data['count_card']*$data_site['ckc_mobi']/100;}
elseif($data['type_card'] == '3'){
    $cash_nhan = $data['count_card']*$data_site['ckc_vina']/100;}
elseif($data['type_card'] == '4'){
    $cash_nhan = $data['count_card']*$data_site['ckc_gate']/100;} 
elseif($data['type_card'] == '5'){
    $cash_nhan = $data['count_card']*$data_site['ckc_vcoin']/100;}
elseif($data['type_card'] == '7'){
    $cash_nhan = $data['count_card']*$data_site['ckc_zing']/100;}
    
}else{
new Redirect("/admin/?act=card"); 
}


?>
<div class="block block-themed">
<div class="block-header bg-info">
<h3 class="block-title">Thông thẻ cào</h3>
</div>
<div class="block-content">
<form class="form-horizontal push-5-t" id="edit" novalidate="novalidate">


<div class="form-group">
<div class="col-xs-6">
<label for="username">Username</label>
<input class="form-control" type="text" value="<?php echo $data['username']; ?>" disabled>
<input type="hidden" name="id" value="<?php echo $id; ?>">
<input type="hidden" name="cash_nhan" value="<?php echo $cash_nhan; ?>">
<input type="hidden" name="username" value="<?php echo $data['username']; ?>">
</div>
<div class="col-xs-6">
<label for="admin">Trạng thái</label>
<input class="form-control" type="text" value="<?php echo $get_info_card->get_string_status_card($data["status"]); ?>" disabled>
</div>
</div>


<div class="form-group">
<div class="col-xs-6">
<label for="username">Loại thẻ</label>
<input class="form-control" type="text" value="<?php echo $get_info_card->get_string_card($data["type_card"]); ?>" disabled>
</div>
<div class="col-xs-6">
<label for="admin">Mệnh giá</label>
<input class="form-control" type="text" value="<?php echo $data['count_card']/1000; ?>K" disabled>
</div>
</div>

<div class="form-group">
<div class="col-xs-6">
<label for="mathe">Mã thẻ</label>
<input class="form-control" type="text" placeholder="<?php echo $data['mathe']; ?>" value="<?php echo $data['mathe']; ?>">
</div>
<div class="col-xs-6">
<label for="seri">Serial</label>
<input class="form-control" type="text" placeholder="<?php echo $data['seri']; ?>" value="<?php echo $data['seri']; ?>">
</div>
</div>

<?php if($data['status'] =='0'){ ?>
<div class="form-group">
<label class="col-xs-12" for="email">Hành động</label>
<div class="col-xs-12">
<div class="col-xs-6">
<input type="radio" name="status" value="1">Nạp thành công<br/>
<input type="radio" name="status" value="2">Nạp thất bại<br/>
</div>
<div class="col-xs-6">
<input type="radio" name="status" value="3">Báo sai mệnh giá<br/>
<input type="radio" name="status" value="4">Bảo trì(chưa nạp thẻ)<br/>
</div>
</div>
</div>





<div class="form-group">
<div class="col-xs-12">
<button class="btn btn-sm btn-success" type="submit">Lưu lại</button>
</div>
</div>
<?php }else{?>
<center style="color:green;">Giao dịch đã được xử lý</center>
<?php }?>
</form>
</div>
</div>
</div>

<script>
  $(document).ready(function () {
      $("#edit").validate({
          submitHandler: function (e) {
          $('button[type="submit"]').html("Đang lưu...");
          $.post("/assets/ajax/edit_card_cham.php", $('#edit').serialize(), function(data) {
              $('button[type="submit"]').html("Lưu lại");
              swal(data.title, data.msg, data.status);
              setTimeout(function () {
              window.location.href = "/admin/?act=card";
              }, 2000);
          }, "json");
              return false;
          }
      });
  });
</script>