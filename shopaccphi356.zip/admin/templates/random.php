
<div class="content content-boxed">
<div class="block block-themed">

<ul class="nav nav-tabs nav-tabs-alt" data-toggle="tabs">
<li class="active">
<a href="#member">Danh sách acc random</a>
</li>
</ul>


<div class="block-content tab-content">

<div class="tab-pane active" id="member">
<div class="row">
    <form action="?act=random" method="post">
  <div class="col-lg-3">
    <div class="input-group">
    <select class="form-control" name="type">
                                    <option value="">Chọn game</option>
                                    <option  value="rd_lq">Liên Quân</option>
                                    <option  value="rd_lol">Liên Minh</option>
                                                                            
                                                         
    </select>
    </div>
  </div>
    
  <div class="col-lg-3">
    <div class="input-group">
      <input class="form-control" placeholder="Tài khoản" id="u" name="u" value="">
    </div>
  </div>
  <div class="col-lg-3">
    <div class="input-group">
      <input class="form-control" placeholder="Mật khẩu" id="p" name="p" value="">
    </div>
  </div>
  <div class="col-lg-3">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-default" type="submit" name="add">Thêm</button>
      </span>
    </div>
  </div>
  </form>
</div>
<hr/>    
 
 <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">ID</th>
                                    <th>TK / MK</th>
                                    <th>Game</th>
                                    <th>Tháo tác</th>
                                </tr></thead>
                        <tbody>
<?php 
if(isset($_GET['del'])):
$db->query("DELETE FROM posts WHERE id_post ='".$_GET['del']."'");
echo '<h4>Xóa ID Random: <font color="blue">#'.$_GET['del'].'</font> thành công !</h4>';
endif;
    
if(isset($_POST['add'])){
if(!empty($_POST['u']) and !empty($_POST['p']) || !empty($_POST['type'])){
    $u = $_POST['u'];
    $type = $_POST['type'];
    $p = $_POST['p'];
$db->query("INSERT INTO `posts` (username,password,date_posted,type_account) VALUES ('$u','$p','$date_current','$type')");
    echo '<h4 style="color:green;">Thêm acc thành công !</h4>';
    
}else{
    echo '<h4 style="color:red;">Vui lòng điền đầy đủ thông tin !</h4>';}
}
    
$i=1;
$sql_get_list_buy = "SELECT * FROM `posts` WHERE status = '0' AND type_account = 'rd_lq' OR type_account = 'rd_lol' ORDER BY `date_posted` DESC LIMIT 1000";
foreach ($db->fetch_assoc($sql_get_list_buy, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $data['id_post']; ?></td>
                                    <td><?php echo $data['username']; ?> / <font color="red"><?php echo $data['password']; ?></font></td>
                                    <?php
                                    if($data['type_account'] == "rd_lq"){$type_acc = "Liên Quân";}else{$type_acc = "Liên Minh";}
                                    ?>
                                    <td><?php echo $type_acc; ?></td>
                                    <td><a href="?act=random&del=<?php echo $data['id_post']; ?>"><button class="btn btn-default">Xóa</button></a></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
 
 
</div>
</div>
</div>
</div>
