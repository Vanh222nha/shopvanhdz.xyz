<?php
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

    $input = new Input;
    // biến truyền vào
    $page = (int)$input->input_post("page");

    /* $_POST */
    $game = $_POST['varchar_1'];
    if($game != ""){
        $sql_game = " type_account = '$game' ";
    }else{
        $sql_game = " type_account = 'rd_lq' OR type_account = 'rd_lol' ";
    }

    $total_record = $db->fetch_row("SELECT COUNT(id_post) FROM posts WHERE
      status = 0 AND
      $sql_game
    "); // đếm hàng

    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "25",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    $paging = new Pagination;
    $get_info = new Info;
    $paging->init($config);

    $sql_get_list_acc = "SELECT * FROM posts WHERE
      status = 0 AND
      $sql_game
    ORDER BY type_post DESC, id_post DESC 
    LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";
?>
<div class="clear"></div>
<ul>
<?php
    // Nếu có tai khoan
    if ($total_record){
        

    foreach ($db->fetch_assoc($sql_get_list_acc, 0) as $key => $data_post){   
        
?>

    
<li>
    <div class="flip-container">
        <div class="flipper">
            <div class="front">
                <div class="account_image">
                    <img src="/assets/images/thumb_random.jpg" />
                    <div class="account_price"><?php echo number_format($data_post["price"], 0, '.', '.'); ?>đ</div>
                    <?php if($data_post['type_post']=='3'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag_vip.png" /></div>
                    <?php elseif($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>                    
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                <div class="account_id">
                    <div class="left">#<?php echo $data_post['id_post']; ?></div>
                    <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
                    <div class="clear"></div>
                </div>
                <div class="account_info">
                    <?php
                    if($data_post['type_account'] == "rd_lq"){$type_acc = "Liên Quân";}else{$type_acc = "Liên Minh";}
                    ?>
                    <p><?php echo $type_acc;?></p>
                </div>
            </div>
            <div class="back">
                <div class="account_detail">
                    <p>#<?php echo $data_post['id_post']; ?></p>
                    <?php echo str_replace("\n", "</p>\n<p>", '<p>'.$data_post["note"].'</p>'); ?>
                    <div class="button_div">
                        <a style="color: white;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="phone_account_list">
        <div class="account_image">
            <img src="/assets/images/thumb_random.jpg" />
            <div class="account_price"><?php echo number_format($data_post["price"]); ?>đ</div>
                    <?php if($data_post['type_post']=='3'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag_vip.png" /></div>
                    <?php elseif($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>                    
                    <?php else: ?>
                    <?php endif; ?>
                    </div>
        <div class="account_id">
            <div class="left">#<?php echo $data_post['id_post']; ?></div>
            <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
            <div class="clear"></div>
        </div>
        <div class="account_info">
                    <?php
                    if($data_post['type_account'] == "rd_lq"){$type_acc = "Liên Quân";}else{$type_acc = "Liên Minh";}
                    ?>
                    <p><?php echo $type_acc;?></p>
                </div>
        <div class="account_detail">
            <?php echo str_replace("\n", "</p>\n<p>", '<p>'.$data_post["note"].'</p>'); ?>            <div class="button_div">
                <a style="color: #fff;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
            </div>
        </div>
    </div>
</li>
 
 <?php
 } // end show acc
 ?>
 </ul>
    <div class="clear"></div>
<?php
 echo $paging->html_site(); // page
?>           

    <div class="clear"></div>
<?php

} else {
?>
<ul>
<?php
  $sql_get_ads = "SELECT * FROM posts WHERE status ='0' AND type_post = '3' AND type_account = 'Liên Quân Mobile' ORDER BY RAND() DESC LIMIT 5";
  foreach ($db->fetch_assoc($sql_get_ads, 0) as $key => $data_post){ 
?>

<li>
    <div class="flip-container">
        <div class="flipper">
            <div class="front">
                <div class="account_image">
                    <img src="<?php echo $get_info->get_thumb($data_post['id_post']); ?>" />
                    <div class="account_price"><?php echo number_format($data_post["price"]); ?>đ</div>
                    <?php if($data_post['type_post']=='3'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag_vip.png" /></div>
                    <?php elseif($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>                    
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                <div class="account_id">
                    <div class="left">#<?php echo $data_post['id_post']; ?></div>
                    <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
                    <div class="clear"></div>
                </div>
                <div class="account_info">
                    <?php
                    if($data_post['type_account'] == "rd_lq"){$type_acc = "Liên Quân";}else{$type_acc = "Liên Minh";}
                    ?>
                    <p><?php echo $type_acc;?></p>
                </div>
            </div>
            <div class="back">
                <div class="account_detail">
                    <p>#<?php echo $data_post['id_post']; ?></p>
                    <?php echo str_replace("\n", "</p>\n<p>", '<p>'.$data_post["note"].'</p>'); ?>
                    <div class="button_div">
                        <a style="color: white;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="phone_account_list">
        <div class="account_image">
            <img src="<?php echo $get_info->get_thumb($data_post['id_post']); ?>" />
            <div class="account_price"><?php echo number_format($data_post["price"]); ?>đ</div>
                    <?php if($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>
                    <?php else: ?>
                    <?php endif; ?>
                    </div>
        <div class="account_id">
            <div class="left">#<?php echo $data_post['id_post']; ?></div>
            <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
            <div class="clear"></div>
        </div>
        <div class="account_info">
                    <?php
                    if($data_post['type_account'] == "rd_lq"){$type_acc = "Liên Quân";}else{$type_acc = "Liên Minh";}
                    ?>
                    <p><?php echo $type_acc;?></p>
                </div>
        <div class="account_detail">
            <p><?php echo nl2br($data_post["note"]); ?></p>            <div class="button_div">
                <a style="color: #fff;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
            </div>
        </div>
    </div>
</li>


<?php
}
?>

<ul>
<li style="color:#313131;width: 100%;float:none;text-align:center;font-size:16px;text-transform: uppercase;margin:0;">Không có tài khoản phù hợp</li>
<?php
}
?>