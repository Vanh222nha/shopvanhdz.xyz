<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
    $username = $db->db_escape(addslashes($_POST['username']));
    $pwd = $db->db_escape(addslashes($_POST['pwd']));
    if ($user) {
		echo json_encode(array("status" => "0", "msg" => "Bạn đang đăng nhập!"));
	}elseif(empty($username) ||empty($pwd)){
		echo json_encode(array("status" => "1", "msg" => "Vui lòng nhập đầy đủ thông tin!!"));
	}elseif ($db->num_rows("SELECT taikhoan FROM accounts WHERE taikhoan = '$username' AND password = '".md5(md5($pwd))."'") < 1) {
		echo json_encode(array("status" => "1", "msg" => "Tài khoản hoặc mật khẩu không chính xác!!"));
	}else{
		echo json_encode(array("status" => "0", "msg" => "Đăng nhập thành công!!"));
    	$session->send($username);//lưu session id fb
    	$db->close(); // Giải phóng
	}
}