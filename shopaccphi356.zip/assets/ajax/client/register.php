<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'){
    $taikhoan = $db->db_escape(addslashes($_POST['taikhoan']));
    $name = $db->db_escape(addslashes($_POST['name']));
    $newemail = $db->db_escape(addslashes($_POST['newemail']));
    $newpwd = $db->db_escape(addslashes($_POST['newpwd']));
    $newpwd2 = $db->db_escape(addslashes($_POST['newpwd2']));
    $phone = $db->db_escape(addslashes($_POST['phone']));

    if ($user) {
		echo json_encode(array("status" => "1", "msg" => "Bạn đã đăng nhập rồi!"));
	}elseif(empty($name)||empty($newemail)||empty($newpwd) ||empty($newpwd2) ||empty($phone)){
		echo json_encode(array("status" => "1", "msg" => "Không thể để trống các trường"));
	}elseif($newpwd2 != $newpwd){
		echo json_encode(array("status" => "1", "msg" => "Xác nhận mật khẩu không khớp"));
		
	}elseif (!filter_var($newemail, FILTER_VALIDATE_EMAIL)) {
		echo json_encode(array("status" => "1", "msg" => "Email không đúng định dạng"));
	}elseif ($db->num_rows("SELECT email FROM accounts WHERE email = '$newemail'") > 0) {
		echo json_encode(array("status" => "1", "msg" => "Email đã có người sử dụng"));
	}elseif ($db->num_rows("SELECT taikhoan FROM accounts WHERE taikhoan = '$taikhoan'") > 0) {
		echo json_encode(array("status" => "1", "msg" => "Tài Khoản đã có người sử dụng"));
	
	}elseif ($db->num_rows("SELECT phone FROM accounts WHERE phone = '$phone'") > 0) {
		echo json_encode(array("status" => "1", "msg" => "Số Điện Thoại đã có người sử dụng"));
	}else{
		echo json_encode(array("status" => "1", "msg" => "Tạo tài khoản thành công!"));
	    $db->query("INSERT INTO `accounts` (username,taikhoan,password,name,email,cash,point,block,admin,time,phone) VALUES ('$taikhoan','$taikhoan','".md5(md5($newpwd))."','$name','$newemail',0,0,0,0,'$date_current','$phone')");
	}
} 