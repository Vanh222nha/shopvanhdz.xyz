<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$email = $db->db_escape(addslashes($_POST['email']));
$taikhoan = $db->db_escape(addslashes($_POST['forgotusername']));
 $captcha;
if(!$email){
echo json_encode(array("status" => "0", "msg" => "Vui Lòng Điền Email !"));
}  
if(!$taikhoan){
echo json_encode(array("status" => "0", "msg" => "Vui Lòng Điền Tài Khoản !"));
} 
if($db->num_rows("SELECT email FROM accounts WHERE email = '$email' AND taikhoan = '$taikhoan' ") < 1){
echo json_encode(array("status" => "0", "msg" => "Email hoặc Tài Khoản Không Tồn Tại Trên Hệ Thống !"));
}else{
 $rdpw = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCD EFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 10);
$db->query("UPDATE `accounts` SET
        `password`='".md5(md5($rdpw))."'
        WHERE `email`='".$email."' AND `taikhoan` = '$taikhoan' ");

$message = "Mật Khẩu Mới Của Bạn Là: $rdpw
Vui Lòng Đăng Nhập Và Đổi Mật Khẩu Tại WebSite $_DOMAIN
Thank You :* :*";
$from = "Xin Chào: $email Yêu Cầu Đổi Mật Khẩu Của Bạn Trên WebSite $_DOMAIN Đã Được Thực Hiện Với IP: $ip  ";
$chude = "Reset Lại Mật Khẩu Thành Công";
mail($email, $chude, $message, $from);
echo json_encode(array("status" => "1", "msg" => "Vui Lòng Đăng Nhập Vào Gmail Để Nhận Mật Khẩu Mới !"));
}
    
