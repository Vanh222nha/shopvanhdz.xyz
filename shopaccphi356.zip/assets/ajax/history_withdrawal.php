<?php
/*
 * 
*/
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user) {
?>
<p class="content-mini content-mini-full bg-warning text-white">Bạn chưa đăng nhập, không thể lấy thông tin</p>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");


$total_record = $db->fetch_row("SELECT COUNT(id) FROM history_atm WHERE username = '{$iduser}' LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "10",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_atm = "SELECT * FROM `history_atm` WHERE `username` = '{$iduser}' ORDER BY `date` DESC LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Thông tin</th>
                                    <th>Số tiền</th>
                                    <th>Nội dung</th>
                                    <th>Trạng thái</th>
                                    <th>Thời gian</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_atm, 0) as $key => $data_atm){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td>
                                    <p>Ngân hàng: <b><?php echo $data_atm['nganhang']; ?></b></p>
                                    <p>Chi nhánh: <b><?php echo $data_atm['chinhanh']; ?></b></p>
                                    <p>Chủ TK: <b><?php echo $data_atm['chutk']; ?></b></p>
                                    <p>Số TK: <b><?php echo $data_atm['sotk']; ?></b></p>
                                    </td>
                                    <td>
                                    <p>Rút <b><?php echo $data_atm['cash']; ?>đ</b></p>
                                    <p>Thực nhận: <b><?php echo $data_atm['cash_nhan']; ?>đ</b></p>
                                    </td>
                                    <td><?php echo $data_atm['note']; ?></td>
                                    <td>
                                        <?php
                                        if($data_atm['status'] == "0"){
                                            echo '<font color="yellow">Đang xử lý</font>';
                                        }elseif($data_atm['status'] == "1"){
                                            echo '<font color="green">Hoàn thành</font>';
                                        }elseif($data_atm['status'] == "2"){
                                            echo '<font color="yellow">Không thành công. Đã hoàn tiền</font>';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $data_atm['date']; ?></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                        </div>
                    
<?php                     
echo $paging->html_withdrawal(); // page
}else {
?>
<p class="content-mini content-mini-full bg-info text-white">Bạn chưa có giao dịch nào</p>
<?php
}
?>




