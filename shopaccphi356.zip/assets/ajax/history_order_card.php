<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$get_info_card = new Info;
if (!$user) {
?>
<p class="content-mini content-mini-full bg-warning text-white">Bạn chưa đăng nhập, không thể lấy thông tin</p>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");


$total_record = $db->fetch_row("SELECT COUNT(id) FROM order_card WHERE username = '{$iduser}' LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "10",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_buy = "SELECT * FROM `order_card` WHERE username = '{$iduser}' ORDER BY `date` DESC LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Thông Tin</th>
                                    <th>Trạng Thái</th>
                                    <th>Thời gian</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_buy, 0) as $key => $data_card){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td>
                                        <p>Loại thẻ: <b><?php echo $get_info_card->get_string_card($data_card["type_card"]); ?></b></p>
                                        <p>Mệnh giá: <b><?php echo number_format($data_card['count_card'], 0, '.', '.'); ?>đ</b></p>
                                        <?php if($data_card["status"] == "1"){ ?>
                                        <p>Serial thẻ: <b><?php echo $data_card['seri']; ?></b></p>
                                        <p>Mã thẻ: <b><?php echo $data_card['pin']; ?></b></p>
                                        <?php }?>
                                    </td>
                                    <td><?php echo $get_info_card->get_order_card($data_card["status"]); ?></td>
                                    <td><?php echo $data_card['date']; ?></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_order_card(); // page
}else {
?>
<p class="content-mini content-mini-full bg-info text-white">Bạn chưa có giao dịch nào</p>
<?php
}
?>




