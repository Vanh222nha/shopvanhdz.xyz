<?php
error_reporting(0);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
$name = addslashes($data_user['name']);
if (!$user) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    
    if (!$_POST['type']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa chọn loại nhà mạng"));
    }elseif (!$_POST['code']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Độ dài mã thẻ hoặc số seri không hợp lệ"));
    }elseif (!$_POST['serial']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Độ dài mã thẻ hoặc số seri không hợp lệ"));
    }else{

    

        $card_type  = $_POST['type'];
        $pin = $_POST['code'];
        $seri  = $_POST['serial'];

	        $cookie_file = _DIR_ . '/' . $seri . '.txt';
	    
	        // acc bên doithenhanh.com
	        $userDoithe = 'blabla@gmail.com'; // mail bên doithenhanh.com
	        $passDoithe = 'blablabla'; // mật khẩu bên doithenhanh.com
	    
	        $ch = curl_init('https://ws.doithenhanh.com/portal/login');
	        curl_setopt_array($ch, array(
	            CURLOPT_POSTFIELDS => '{"username":"'. $userDoithe .'","password":"'. $passDoithe .'"}',
	            CURLOPT_HTTPHEADER => array('content-type: application/json;charset=UTF-8'),
	            CURLOPT_COOKIEJAR => $cookie_file,
	            CURLOPT_COOKIEFILE => $cookie_file,
	            CURLOPT_RETURNTRANSFER => true,
	        ));
	        $login = json_decode(curl_exec($ch));
	        if (isset($login->code) && $login->code == 0) {
	            $access_token = $login->token->value;
	            curl_setopt($ch, CURLOPT_URL, 'https://ws.doithenhanh.com/portal/charge');
	            curl_setopt($ch, CURLOPT_HTTPHEADER, array('content-type: application/json;charset=UTF-8', 'x-access-token: ' . $access_token));
	            curl_setopt($ch, CURLOPT_POSTFIELDS , '{"pin":"'. $pin .'","provider":"'. $card_type .'","serial":"'. $seri .'"}');
	            $charge = json_decode(curl_exec($ch));
        if (isset($charge->code) && $charge->code == 0) {
	                
            $info_card = str_replace(array('Nạp thành công thẻ ', ' đ.', ','), '', $charge->message); // số tiền từ card
      $amount = $miu_topup->get_price();
      
          
            if($info_card == 20000){
        	$db->query("UPDATE `accounts` SET `point` = `point` + '0' WHERE `username` = '{$iduser}'");
            }elseif($info_card == 50000){
        	$db->query("UPDATE `accounts` SET `point` = `point` + '1' WHERE `username` = '{$iduser}'");
            }elseif($info_card == 100000){
        	$db->query("UPDATE `accounts` SET `point` = `point` + '2' WHERE `username` = '{$iduser}'");
            }elseif($info_card == 200000){
        	$db->query("UPDATE `accounts` SET `point` = `point` + '4' WHERE `username` = '{$iduser}'");
            }elseif($info_card == 500000){
        	$db->query("UPDATE `accounts` SET `point` = `point` + '10' WHERE `username` = '{$iduser}'");
            }else{
            #nothing    
            }
            $now = getdate();
        	$db->query("UPDATE accounts SET `cash` = `cash` + $info_card WHERE `username` = $iduser");// cộng tiền
            $db->query("INSERT INTO `history_card` (username,name,type_card,count_card,time) VALUES ('$iduser','$name','$card_type','$info_card','$date_current')");// lịch sử
            
        echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => $charge->message));
    }
    else {
                echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => $charge->message));
    
    }

} else {
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Hãy cấu hình lại doithenhanh.com"));
}
curl_setopt($ch, CURLOPT_COOKIEJAR, false);
curl_close($ch);



}
}
?>