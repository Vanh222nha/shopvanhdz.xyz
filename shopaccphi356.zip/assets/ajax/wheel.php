<?php
/*
 * wheel.php 

 */
// Require database & thông tin chung
require_once '../../core/init.php';

if (!$user) {// nếu chưa đăng nhập 
$status = -1; // false
$errormessage = "Bạn chưa đăng nhập";
}else{
	$vongquay = $_POST['spin'];
	$status = 1; // true
	if($vongquay == 0){
		$gift = "Thêm lượt";
	}else if($vongquay == 1){
		$gift ="ACC CF "; 
	}else if($vongquay == 2) {
		$gift ="+10K Cash Web";
	}else if($vongquay == 3) {
		$gift ="Mất lượt";
	}else if($vongquay == 4) {
		$gift ="+200K Cash Web";
	}else if($vongquay == 5) {
		$gift ="Card điện thoại";
	}else if($vongquay == 6) {
		$gift ="100 VC";
	}else if($vongquay == 7) {
		$gift ="Mất lượt";
	}else {
		//rỗng
	}

}
?>

{"status":<?=$status?>,"errormessage":"<?=$errormessage?>","gift":"<?=$gift?>","spin":"<?=$vongquay?>"}