<?php
/*
 * settings.php 

 * Chuc nang: lưu dữ liệu trang web
 */
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$input = new Input;
// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{
    
    $username = $_POST['username'];
    $status = $_POST['status'];
    $cash_nhan = $_POST['cash_nhan'];
    $id = $_POST['id'];
    
    $sql_get = "SELECT * FROM history_card where `id` = {$id} LIMIT 1";
    $data = $db->fetch_assoc($sql_get, 1);
    
    if($data['status'] != 0){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Giao dịch đã được xử lý rồi")); exit;}
        
    $db->query("UPDATE history_card SET `status` = '{$status}' WHERE `id` = '{$id}'");// trang thai
    
    if($status == "3"){$cash_nhan = $cashnhan*0.5;}elseif($status == "4" || $status == "2"){$cash_nhan = 0;}
    
    $db->query("UPDATE accounts SET `cash` = `cash` + '{$cash_nhan}' WHERE `username` = '{$username}'");
    
    echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Đã xử lý giao dịch"));
    
    
    
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>