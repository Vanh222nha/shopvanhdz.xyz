<div class="sl-hdtop">
        <div class="container">
            <div class="sl-boxs">
                <div class="sl-row clearfix">
                    
<div class="sl-col sl-col1">
    <div class="sl-hdcbox" id="napthe">
<div class="sl-hdcbox">
    <iframe width="560" height="450" src="<?php echo $data_site['video_home']; ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
    </div>




    </div>
</div>

                    
<div class="sl-col sl-col2">
    <div class="sl-hdcbox">
            <div class="swiper-container slhdbner swiper-container-horizontal">
                <div class="swiper-wrapper">
                        <div class="swiper-slide swiper-slide-active" style="width: 789px; margin-right: 1px;"><img src="/assets/images/636559827881834923_bn.jpg" alt=""></div>
                </div>
                <div class="fsbn-p swiper-button-disabled"></div>
                <div class="fsbn-n swiper-button-disabled"></div>
                <div class="swiper-pagination swiper-pagination-clickable swiper-pagination-bullets"><span class="swiper-pagination-bullet swiper-pagination-bullet-active"></span></div>
            </div>
    </div>
</div>
                </div>
            </div>
        </div>
    </div>
             <div class="container" style="padding: 10px 10px ;">
<div class="sa-lpi">
        <div class="sa-lprod">
<marquee scrollamount="5" style="padding: 4px;padding-top: 9px;">
<?php
    $sql_get_list_buy = "SELECT * FROM `history_buy` ORDER BY `time` DESC LIMIT 15";
        if ($db->num_rows($sql_get_list_buy)){
        foreach ($db->fetch_assoc($sql_get_list_buy, 0) as $key => $data_buy){   
    ?>

<img src="https://lmhtshop.com/assets/images/run.gif" alt="chay" longdesc="5"><a href="https://facebook.com/<?php echo $data_buy['username']; ?>" target="_blank"><span style="color: yellow;" ><?php echo $data_buy['name']; ?></span></a> Mua tài khoản <?php echo $data_buy['loaiacc']; ?><span style="color: yellow;" ><a href="<?php echo $_DOMAIN.''.$data_buy['id_post']; ?>.html" target="_blank">#<?php echo $data_buy['id_post']; ?> </a></span> với giá <span style="color: yellow;" ><?php echo number_format($data_buy["price"], 0, '.', '.'); ?></span><sup class="text-muted">Card</sup>Cách đây <?php echo time_elapsed_string($data_buy['time']); ?>
<?php
}}
?>


</marquee>
           
</div>          
</div>
</div>
<style>
    .sa-lpi {
    border: 1px solid #262626;
    background: #000000;
    position: relative;
    overflow: hidden;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    margin-bottom: 20px;
}.sa-lprod {
    background: #141414;
    padding: 2px;
}
</style>
