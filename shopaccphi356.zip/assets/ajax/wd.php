<?php
session_start();
error_reporting(E_ALL^E_NOTICE);
error_reporting(E_ERROR);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
if (!$user) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    $bank = $_POST['bank'];
    $chinhanh = $_POST['chinhanh'];
    $chutk = $_POST['chutk'];
    $sotk = $_POST['sotk'];
    $cash = $_POST['cash'];
    $cash_nhan = $cash - 10000;
    $note = $_POST['note'];
    $password = md5(md5($_POST['password']));
    if(empty($bank) || empty($cash) || empty($chinhanh) || empty($chutk) || empty($sotk) || empty($password)){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Thông tin (*) không được để trống !"));exit;}
    if($cash < 50000){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số tiền rút ít nhất là 50.000đ"));exit;}
    if($cash > $data_user['cash']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số dư của bạn không đủ để thực hiện giao dịch"));exit;}
    if($password != $data_user['password']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Mật khẩu không chính xác"));exit;}
        
    $db->query("UPDATE accounts SET `cash` = `cash` - '{$cash}' WHERE `username` = '{$iduser}'");// trừ tiền 
    $db->query("INSERT INTO `history_atm` (username,cash,cash_nhan,nganhang,chinhanh,chutk,sotk,note,date,status) VALUES ('$iduser','$cash','$cash_nhan','$bank','$chinhanh','$chutk','$sotk','$note','$date_current',0)");// lịch sử    
    echo json_encode(array('code' => 0, 'status' => "success",'title' => "Thành công",'msg' => "Gửi yêu cầu thành công. Vui lòng đợi Admin xử lý!"));
}