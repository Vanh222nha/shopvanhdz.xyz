<?php
//error_reporting( E_ALL );
//ini_set('display_errors', 1);
/*

 */
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');


    $input = new Input;
    // biến truyền vào
    $page = (int)$input->input_post("page");

    /* $_POST */
    $min_price = !empty($_POST['min_price']) ? (int)$_POST['min_price'] : 0;
    $max_price = !empty($_POST['max_price']) ? (int)$_POST['max_price'] : 10000000;
    $tuong = !empty($_POST['int_1']) ? (int)str_replace('.', '', $_POST['int_1']) : 0;
    $skin = !empty($_POST['int_2']) ? (int)str_replace('.', '', $_POST['int_2']) : 0;
    $ip = !empty($_POST['int_3']) ? (int)str_replace('.', '', $_POST['int_3']) : 0;
    $rank = !empty($_POST['int_5']) ? (int)str_replace('.', '', $_POST['int_5']) : 1;
    $khung = !empty($_POST['varchar_1']) ? (int)mysqli_real_escape_string($_POST['varchar_1']) : -1;



    if ($khung == -1) {
      $sql_khung = "";
    } else if ($khung == -2) {
      $sql_khung = "frame = 0 AND ";
    } else {
      $sql_khung = "frame = $khung AND ";
    }
    if ($rank == -1) $rank = 0;
    /* Phân ra rank */
    $sql_rank = "";
    if ($rank == 1) {
       $sql_rank = "";
    } else if ($rank == -2) {
      $sql_rank = " rank BETWEEN 12 AND 28 AND ";
    } elseif (in_array($rank, array(0, 27, 28))) {
       $sql_rank = "rank = $rank AND";
    } else if (in_array($rank, array(2, 3, 4, 5, 6))) {
       $sql_rank = "rank BETWEEN 2 AND 6 AND ";
    } else if (in_array($rank, array(7, 8, 9, 10, 11))) {
       $sql_rank = "rank BETWEEN 7 AND 11 AND ";
    } else if (in_array($rank, array(12, 13, 14, 15, 16))) {
       $sql_rank = "rank BETWEEN 12 AND 16 AND ";
    } else if (in_array($rank, array(17, 18, 19, 20, 21))) {
       $sql_rank = "rank BETWEEN 17 AND 21 AND ";
    } else if (in_array($rank, array(22, 23, 24, 25, 26))) {
       $sql_rank = "rank BETWEEN 22 AND 26 AND ";
    }
    /* END */

    $total_record = $db->fetch_row("SELECT COUNT(id_post) FROM posts WHERE
      status = 0 AND
      type_account = 'Liên Quân Mobile' AND
      price BETWEEN $min_price AND $max_price AND 
      $sql_rank
      skins_count >= $skin AND 
      champs_count >= $tuong AND 
      $sql_khung 
      ip_count >= $ip
    "); // đếm hàng

    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "25",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    $paging = new Pagination;
    $get_info = new Info;
    $paging->init($config);

    $sql_get_list_acc = "SELECT * FROM posts WHERE
      status = 0 AND
      type_account = 'Liên Quân Mobile' AND
      price BETWEEN $min_price AND $max_price AND 
      $sql_rank
      skins_count >= $skin AND 
      champs_count >= $tuong AND 
      $sql_khung 
      ip_count >= $ip
    ORDER BY type_post DESC, id_post DESC 
    LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";
?>
<div class="clear"></div>
<ul>
<?php
    // Nếu có tai khoan
    if ($total_record){
        

    foreach ($db->fetch_assoc($sql_get_list_acc, 0) as $key => $data_post){   
        
?>

    
<li>
    <div class="flip-container">
        <div class="flipper">
            <div class="front">
                <div class="account_image">
                    <img src="<?php echo $get_info->get_thumb($data_post['id_post']); ?>" />
                    <div class="account_price"><?php echo number_format($data_post["price"], 0, '.', '.'); ?>đ</div>
                    <?php if($data_post['type_post']=='3'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag_vip.png" /></div>
                    <?php elseif($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>                    
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                <div class="account_id">
                    <div class="left">#<?php echo $data_post['id_post']; ?></div>
                    <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
                    <div class="clear"></div>
                </div>
                <div class="account_info">
                    <p><?php echo $data_post['champs_count']; ?> tướng</p>
                    <p><?php echo $data_post['skins_count']; ?> trang phục</p>
                    <div class="account_icon">
                        <img src="<?php echo $get_info->get_icon_rank($data_post['rank']); ?>" />
                    </div>
                </div>
            </div>
            <div class="back">
                <div class="account_detail">
                    <p>#<?php echo $data_post['id_post']; ?></p>
                    <?php echo str_replace("\n", "</p>\n<p>", '<p>'.$data_post["note"].'</p>'); ?>
                    <div class="button_div">
                        <a style="color: white;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="phone_account_list">
        <div class="account_image">
            <img src="<?php echo $get_info->get_thumb($data_post['id_post']); ?>" />
            <div class="account_price"><?php echo number_format($data_post["price"]); ?>đ</div>
                    <?php if($data_post['type_post']=='3'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag_vip.png" /></div>
                    <?php elseif($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>                    
                    <?php else: ?>
                    <?php endif; ?>
                    </div>
        <div class="account_id">
            <div class="left">#<?php echo $data_post['id_post']; ?></div>
            <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
            <div class="clear"></div>
        </div>
        <div class="account_info">
            <p><?php echo $data_post['champs_count']; ?> tướng</p>
            <p><?php echo $data_post['skins_count']; ?> trang phục</p>
            <div class="account_icon">
                        <img src="<?php echo $get_info->get_icon_rank($data_post['rank']); ?>" />
            </div>
        </div>
        <div class="account_detail">
            <?php echo str_replace("\n", "</p>\n<p>", '<p>'.$data_post["note"].'</p>'); ?>            <div class="button_div">
                <a style="color: #fff;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
            </div>
        </div>
    </div>
</li>
 
 <?php
 } // end show acc
 ?>
 </ul>
    <div class="clear"></div>
<?php
 echo $paging->html_site(); // page
?>           

    <div class="clear"></div>
<?php

} else {
?>
<ul>
<?php
  $sql_get_ads = "SELECT * FROM posts WHERE status ='0' AND type_post = '3' AND type_account = 'Liên Quân Mobile' ORDER BY RAND() DESC LIMIT 5";
  foreach ($db->fetch_assoc($sql_get_ads, 0) as $key => $data_post){ 
?>

<li>
    <div class="flip-container">
        <div class="flipper">
            <div class="front">
                <div class="account_image">
                    <img src="<?php echo $get_info->get_thumb($data_post['id_post']); ?>" />
                    <div class="account_price"><?php echo number_format($data_post["price"]); ?>đ</div>
                    <?php if($data_post['type_post']=='3'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag_vip.png" /></div>
                    <?php elseif($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>                    
                    <?php else: ?>
                    <?php endif; ?>
                </div>
                <div class="account_id">
                    <div class="left">#<?php echo $data_post['id_post']; ?></div>
                    <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
                    <div class="clear"></div>
                </div>
                <div class="account_info">
                    <p><?php echo $data_post['champs_count']; ?> tướng</p>
                    <p><?php echo $data_post['skins_count']; ?> trang phục</p>
                    <div class="account_icon">
                        <img src="<?php echo $get_info->get_icon_rank($data_post['rank']); ?>" />
                    </div>
                </div>
            </div>
            <div class="back">
                <div class="account_detail">
                    <p>#<?php echo $data_post['id_post']; ?></p>
                    <?php echo str_replace("\n", "</p>\n<p>", '<p>'.$data_post["note"].'</p>'); ?>
                    <div class="button_div">
                        <a style="color: white;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="phone_account_list">
        <div class="account_image">
            <img src="<?php echo $get_info->get_thumb($data_post['id_post']); ?>" />
            <div class="account_price"><?php echo number_format($data_post["price"]); ?>đ</div>
                    <?php if($data_post['type_post']=='1'): ?>
                    <div class="tag"><img src="/assets/img/tag_ads.png" /></div>
                    <?php elseif($data_post['type_post']=='2'): ?>
                    <div class="tag"><img src="/assets/img/tag.png" /></div>
                    <?php else: ?>
                    <?php endif; ?>
                    </div>
        <div class="account_id">
            <div class="left">#<?php echo $data_post['id_post']; ?></div>
            <div class="right"><?php echo date('d-m-Y', strtotime($data_post['date_posted'])); ?></div>
            <div class="clear"></div>
        </div>
        <div class="account_info">
            <p><?php echo $data_post['champs_count']; ?> tướng</p>
            <p><?php echo $data_post['skins_count']; ?> trang phục</p>
            <div class="account_icon">
                        <img src="<?php echo $get_info->get_icon_rank($data_post['rank']); ?>" />
            </div>
        </div>
        <div class="account_detail">
            <p><?php echo nl2br($data_post["note"]); ?></p>            <div class="button_div">
                <a style="color: #fff;" href="/<?php echo $data_post['id_post']; ?>.html" target="_blank"><button>Xem chi tiết</button></a>
            </div>
        </div>
    </div>
</li>


<?php
}
?>

<ul>
<li style="color:#313131;width: 100%;float:none;text-align:center;font-size:16px;text-transform: uppercase;margin:0;">Không có tài khoản phù hợp</li>
<?php
}
?>