<?php
/*
 * settings.php 

 * Chuc nang: trạng thái thẻ cào
 */
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$input = new Input;

// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{
    $trangthai = trim(htmlspecialchars(addslashes($_POST['trangthai'])));
    $id = addslashes(htmlspecialchars($_POST['id']));
 
    $sql_info = "UPDATE history_card SET 
            status ='$trangthai'
            WHERE `id` = '$id'";;
    $db->query($sql_info);
    $db->close();
    
    echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Thành công"));
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>