<?php

// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

        $id = trim(addslashes(htmlspecialchars($_POST['id'])));
        $sql_get_data = "SELECT * FROM posts WHERE id_post = '{$id}' AND `status` = '0' LIMIT 1";
        $info = $db->fetch_assoc($sql_get_data, 1);  
        $iduser = $data_user['username'];
        $name = addslashes($data_user['name']);
        $helper = $fb->getRedirectLoginHelper();
        $permissions = ['email'];  // set the permissions. 
        $loginUrl = $helper->getLoginUrl(''.$_DOMAIN.'/login.php', $permissions);
        // check đặt cọc
        $sql_get_pre = "SELECT * FROM `pre_order` WHERE id_post = '{$id}' AND `username` = '{$iduser}' AND `status` = '0' LIMIT 1";
        $sql_check_pre = "SELECT * FROM `pre_order` WHERE id_post = '{$id}' AND `username` != '{$iduser}' AND `status` = '0' LIMIT 1";
        $get_pre = $db->fetch_assoc($sql_get_pre, 1);  
        // get 
        $pre = $db->fetch_assoc("SELECT * FROM pre_order WHERE id_post = '".$get_pre['id_post']."' AND `username` = '{$iduser}' AND `status` = '0' LIMIT 1", 1); 
        // điều kiện hết hạn
        if($pre['time'] - time() <= 0){
        $db->query("UPDATE `pre_order` SET `status` = '2' WHERE `id_post` = '{$id}' LIMIT 1");// status    
        }

        if (!$user) {
        echo json_encode(array('status' => "error", 'link' => "$loginUrl", 'title' => "Lỗi", 'message' => "Bạn chưa đăng nhập"));
        }else if (!$id) {
        echo json_encode(array('status' => "error", 'link' => "/index.php", 'title' => "Lỗi", 'message' => "Bạn chưa chọn tài khoản"));
        }else if ($db->num_rows($sql_check_pre) >= 1) {
        echo json_encode(array('status' => "error", 'link' => "/index.php", 'title' => "Lỗi", 'message' => "Tài khoản này đã được đặt cọc bởi người khác"));
        }else if($data_site['status']==0) {
        echo json_encode(array('status' => "error", 'link' => "/$id.html", 'title' => "Lỗi", 'message' => "Trang web của chúng tôi đang tạm dừng giao dịch, quay lại sau"));
        }else if (!$_POST) {
        echo json_encode(array('status' => "error", 'link' => "/index.php", 'title' => "Lỗi", 'message' => "Vui lòng xác minh lại giao thức"));
        }else if ($db->num_rows($sql_get_data) < 1) {
        echo json_encode(array('status' => "error", 'link' => "/index.php", 'title' => "Lỗi", 'message' => "Tài khoản bạn chọn không tồn tại hoặc đã bị mua bởi người khác"));
        }else if ($data_user['cash'] < $info['price'] ) {
        echo json_encode(array('status' => "error", 'link' => "/recharge", 'title' => "Lỗi", 'message' => "Bạn không đủ tiền để mua, vui lòng nạp thêm"));
        }else{
            
            echo json_encode(array('status' => "success", 'link' => "/transaction.html", 'title' => "Thành công", 'message' => "Giao dịch thành công"));
            $db->query("UPDATE `posts` SET `status` = '1' WHERE `id_post` = '{$id}' LIMIT 1");// status

            if ($db->num_rows($sql_get_pre) >= 1) { // nếu có đặt cọc và id username là id hiện tại
            $price = $info['price'] - $pre['price'];
            $db->query("UPDATE `accounts` SET `cash` = `cash` - '{$price}' WHERE `username` = '{$iduser}'");// trừ tiền chưa cọc còn lại
            $db->query("UPDATE `pre_order` SET `status` = '1' WHERE `id_post` = '{$id}' LIMIT 1");// status
            }else{
            $price = $info['price'];
            $db->query("UPDATE `accounts` SET `cash` = `cash` - '{$info['price']}' WHERE `username` = '{$iduser}'");// trừ tiền
            }
            $price_show = $info['price'];
            $loaiacc = $info['type_account'];
            $db->query("INSERT INTO `history_buy` (username,name,loaiacc,id_post,price,time) VALUES ('$iduser','$name','$loaiacc','$id','$price_show','$date_current')");// lịch sử
            
            
            

            // xóa ảnh
            $arr_delete = array();
            $avatar = glob("../files/thumb/".$id.".*");
            $arr_delete[] = $avatar[0];
            $gem = glob("../files/gem/".$id."-*");
            foreach ($gem as $link_gem) {
            $arr_delete[] = $link_gem;
            }
            $post = glob("../files/post/".$id."-*");
            foreach ($post as $link_post) {
            $arr_delete[] = $link_post;
            }
            foreach ($arr_delete as $link) {
            @unlink($link);
            }


        }