<?php
/*
 * settings.php 

 * Chuc nang: lưu dữ liệu trang web
 */
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$input = new Input;
// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{
    
    $username = $_POST['username'];
    $status = $_POST['status'];
    $id = $_POST['id'];
    $seri = $_POST['seri'];
    $pin = $_POST['pin'];
    $sql_get = "SELECT * FROM order_card where `id` = {$id} LIMIT 1";
    $data = $db->fetch_assoc($sql_get, 1);
    
    if($data['status'] != 0){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Giao dịch đã được xử lý rồi")); exit;}
    
    if($status == 1){
        if(empty($seri) || empty($pin)){
            echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Không được để trống thông tin thẻ !")); exit;}
    }else{
        $cash = $data['count_card']*$data_site['ck_card']*0.01;
        $db->query("UPDATE accounts SET `cash` = `cash` + '{$cash}' WHERE `username` = '{$username}'");}
        
    $db->query("UPDATE order_card SET `status` = '{$status}',`seri` = '{$seri}',`pin` = '{$pin}' WHERE `id` = '{$id}'");// trang thai
    
    echo json_encode(array('code' => "0",'status' => "success", 'title' => "Thành công", 'msg' => "Xử lý thành công !"));
    
    
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>