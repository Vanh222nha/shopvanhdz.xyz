<?php
/*
 * settings.php 

 * Chuc nang: lưu dữ liệu trang web
 */
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');

$input = new Input;
// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{
    $username = trim(htmlspecialchars(addslashes($_POST['username'])));
    $status = $_POST['status'];
    $cash = trim(htmlspecialchars(addslashes($_POST['cash'])));
    $id = $_POST['id'];
    
    $sql_get = "SELECT * FROM history_card where `id` = {$id} LIMIT 1";
    $data = $db->fetch_assoc($sql_get, 1);
    
    if($data['status'] != 0){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Giao dịch đã được xử lý rồi")); exit;
    }
 
    if($status == "1"){
    $db->query("UPDATE history_atm SET `status` = '1' WHERE `id` = '{$id}'");
    echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Đã duyệt chuyển tiền"));
    }elseif($status == "2"){
        $db->query("UPDATE accounts SET `cash` = `cash` + '{$cash}' WHERE `username` = '{$username}'");// + tiền
        $db->query("UPDATE history_atm SET `status` = '2' WHERE `id` = '{$id}'");// + tiền
        echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Hủy giao dịch. Đã hoàn tiền"));
    }elseif($status == "0"){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa xử lý giao dịch"));
    }
    
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>