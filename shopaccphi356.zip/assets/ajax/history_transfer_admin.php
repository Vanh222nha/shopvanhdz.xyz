<?php
/*
 */
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user && $data_user['admin'] < 1) {
?>
<p class="content-mini content-mini-full bg-warning text-white">Bạn chưa đăng nhập, không thể lấy thông tin</p>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");
$username = $input->input_post("username4");

if (!empty($username)) {
$sql_username = "AND user_nhan LIKE '%$username%' OR user_gui LIKE '%$username%'";
}

$total_record = $db->fetch_row("SELECT COUNT(id) FROM history_transfer WHERE id != '0' $sql_username LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_transfer = "SELECT * FROM `history_transfer` WHERE id != '0' $sql_username ORDER BY `time` DESC LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Thông tin</th>
                                    <th>Nội dung</th>
                                    <th>Thời gian</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_transfer, 0) as $key => $data_transfer){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td><font color="green"><?php echo $data_transfer['user_gui']; ?></font> chuyển <font color="red"><?php echo $data_transfer['cash']; ?>đ</font> cho <font color="blue"><?php echo $data_transfer['user_nhan']; ?></font></td>
                                    <td><?php echo $data_transfer['note']; ?></td>
                                    <td><?php echo $data_transfer['time']; ?></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_transfer(); // page
}else {
?>
<p class="content-mini content-mini-full bg-info text-white">Không tìm thấy giao dịch</p>
<?php
}
?>




