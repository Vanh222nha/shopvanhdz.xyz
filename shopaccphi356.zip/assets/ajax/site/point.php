<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user) {
echo'<p id="point">Dm! Đăng Nhập Đi Mà Quay</p>';
}elseif($data_user['point']<1){
echo'<p id="point">Không Có Lượt Quay Tính Làm Gì!</p>';
}else{
echo'<p id="point">BẠN CÓ '.number_format($data_user['point'], 0, '.', '.').' POINT</p>';
}
?>