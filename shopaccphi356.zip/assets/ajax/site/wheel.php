<?php
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
    $point = 2; // mỗi lần quay là 2 point
    $iduser = $data_user['username'];

if (!$user) {
    echo json_encode(array('status' => '-1', 'errormessage' => "Bạn chưa đăng nhập"));
}elseif ($data_user['point'] < $point) {
    echo json_encode(array('status' => '-1', 'errormessage' => "Bạn không có lượt quay, hãy nạp thẻ hoặc mua một tài khoản để có lượt quay"));
}else{
    $degrees = rand(0, 359);
    $quay = 8 - 1 - floor($degrees / (360 / 8)); 
    $text = array('Nhận được 10.000 VNĐ','Nhận được Account CF','Nhận được Card điện thoại','Chúc bạn may mắn lần sau','Nhận được 20.000 VNĐ','Nhận được Account CF','100 RP','Chúc bạn may mắn lần sau');
    // Tọa độ : 209: trật, 230;247: card, 93: acc LM


    // Gian lận
    if($quay == 6){// RP 0% 
        $tile = rand(0,100);
        if($tile <= 70){
        $degrees = rand(350,358);
        $quay = 0;
        $history = 1;
        $price = 10000;
        $db->query("UPDATE `accounts` SET `cash` = `cash` + '{$price}' WHERE `username` = '{$iduser}'");        
        $text_us = $text[0];
        }else{
        $degrees = rand(207,211);
        $quay = 3;
        $history = 0;            
        }
        
    }elseif($quay == 2){// card 0%
        $tile = rand(0,100);
        if($tile <= 70){
        $degrees = rand(350,358);
        $quay = 0;
        $history = 1;
        $price = 10000;
        $db->query("UPDATE `accounts` SET `cash` = `cash` + '{$price}' WHERE `username` = '{$iduser}'");        
        $text_us = $text[0];
        }else{
        $degrees = rand(207,211);
        $quay = 3;
        $history = 0;            
        }
    }elseif ($quay == 1 || $quay == 5) { // Acc cf 10%

        if ($db->num_rows("SELECT * FROM wheel_acc WHERE status != '1' LIMIT 1") > 0) {
            $info = $db->fetch_assoc("SELECT * FROM wheel_acc WHERE status != '1' Order by Rand() limit 1", 1);
            $tile = rand(0,100);
            if($tile <= 50){
            $history =1;
            $text_us = "Account CF bạn nhận được là ".$info['username']." / ".$info['pass']."";
            $db->query("UPDATE `wheel_acc` SET `status` = '1' WHERE `id` = '{$info['id']}'");
            }else{
            $history =0;
            $quay = 3;
            $degrees = rand(207,211);
            }
         }else{ // neếu không có acc trong csdl thì auto trật
            $degrees = rand(207,211);
            $quay = 3;
            $history = 0;            
        }
        
    }elseif ($quay == 0) { // 10k 40% 
        $history =1;
        $price = 10000;
        $db->query("UPDATE `accounts` SET `cash` = `cash` + '{$price}' WHERE `username` = '{$iduser}'");
        $text_us = $text[0];
    }elseif ($quay == 4) { // 20k 10%
        $history =0;
        $quay = 3;
        $degrees = rand(207,211);
        
    }else{
        // notthing
    } 
    
    // trừ point
    $db->query("UPDATE `accounts` SET `point` = `point` - '{$point}' WHERE `username` = '{$iduser}'");
    // lịch sử
    if($history==1){
    $db->query("INSERT INTO `wheel_history` (fb,text,text_us,date) VALUES ('$iduser','".$text[$quay]."','$text_us','".time()."')");
    }else{
    // nothing    
    }
    //send thưởng
    echo json_encode(array('status' => '0', 'degrees' => $degrees, 'gift' => $text[$quay]));
}
