<?php
/*
 *

 */
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$path = '../files/'; // patch lưu file

// Nếu đăng nhập và là admin
if ($user && $data_user['admin'] > 0) {

    $total_info = count($_FILES["info"]["name"]);
    $thumb = count($_FILES["thumb"]["name"]);
    $username = addslashes(htmlspecialchars($_POST['username']));
    $password = addslashes(htmlspecialchars($_POST['password']));
    $price = addslashes(htmlspecialchars($_POST['price']));
    $price_atm = addslashes(htmlspecialchars($_POST['price_atm']));
        $chbm = addslashes(htmlspecialchars($_POST['chbm']));
		    $email = addslashes(htmlspecialchars($_POST['email']));
			    $cmnd = addslashes(htmlspecialchars($_POST['cmnd']));
    $gtdh = addslashes(htmlspecialchars($_POST['gtdh']));
    $ep = addslashes(htmlspecialchars($_POST['ep']));

    $note = addslashes(htmlspecialchars($_POST['note']));
    $type_post = addslashes(htmlspecialchars($_POST['type_post']));

      // điều kiện post
      if (empty($username)){
      echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa Nhập đủ thông tin"));
      }else{

        $sql_add_post = "INSERT INTO posts VALUES (
                        '',
                        '$username',
                        '$password',
                        '$price',
                        '$price_atm',
						'$chbm',
						'$email',
						'$cmnd',
                        '',
                        '',
                        '',
                        '',
                        '',
                        '',
                        '',
                        '',
                        '',
                        '',
                        '$note',
                        '$type_post',
                        'Đột Kích',
                        '$date_current',
                        '0'
                    )";
        $db->query($sql_add_post); // insert vào csdl
        $id_new = $db->insert_id();

        // ảnh tướng
        for ($i = 0; $i < $total_info; $i++) {
          if ($_FILES["champs"]["error"][$i] == 0) {
             $arr = explode(".", $_FILES["info"]["name"][$i]);
             move_uploaded_file($_FILES["info"]["tmp_name"][$i], $path."post/".$id_new."-".($i + 1).".".end($arr));
          }
       } 
       
       // ảnh index
        if ($_FILES["thumb"]["error"] == 0) {
            $arr = explode(".", $_FILES["thumb"]["name"]);
            move_uploaded_file($_FILES["thumb"]["tmp_name"], $path."thumb/".$id_new.".".end($arr));
        }

        echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Đăng tài khoản #$id_new thành công"));
        $db->close(); // Giải phóng

      }

} else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}