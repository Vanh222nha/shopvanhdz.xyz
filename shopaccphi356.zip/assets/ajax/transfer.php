<?php
session_start();
error_reporting(E_ALL^E_NOTICE);
error_reporting(E_ERROR);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
if (!$user) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    $username = $_POST['username'];  
    $cash = $_POST['cash'];
    $note = $_POST['note'];
    $password = md5(md5($_POST['password']));
    if(empty($username) || empty($cash) || empty($password)){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Thông tin (*) không được để trống !"));exit;}
    if($db->num_rows("SELECT username FROM accounts WHERE username = '$username'") < 1){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Người nhận không tồn tại"));exit;}
    if($username == $iduser){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn không thể chuyển tiền cho chính mình"));exit;}
    if($cash < 10000){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số tiền chuyển ít nhất là 10.000đ"));exit;}
    if($cash > $data_user['cash']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số dư của bạn không đủ để thực hiện giao dịch"));exit;}
    if($password != $data_user['password']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Mật khẩu không chính xác"));exit;}
        
    $db->query("UPDATE accounts SET `cash` = `cash` + '{$cash}' WHERE `username` = '{$username}'");// cộng tiền 
    $db->query("UPDATE accounts SET `cash` = `cash` - '{$cash}' WHERE `username` = '{$iduser}'");// trừ tiền 
    $db->query("INSERT INTO `history_transfer` (user_nhan,user_gui,cash,note,time) VALUES ('$username','$iduser','$cash','$note','$date_current')");// lịch sử    
    echo json_encode(array('code' => 0, 'status' => "success",'title' => "Thành công",'msg' => "Chuyển $cash đ cho $username thành công!"));
}