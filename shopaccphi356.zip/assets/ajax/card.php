<?php
session_start();
error_reporting(E_ALL^E_NOTICE);
error_reporting(E_ERROR);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
$name = addslashes($data_user['name']);
$ck = $data_site['ck']/100;
if (!$user) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    
    if (!$_POST['card_type_id']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa chọn loại nhà mạng"));
    }elseif (!$_POST['price_guest']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa chọn mệnh giá thẻ"));
    }elseif (!$_POST['pin']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Độ dài mã thẻ hoặc số seri không hợp lệ"));
    }elseif (!$_POST['seri']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Độ dài mã thẻ hoặc số seri không hợp lệ"));
    }else{
    
    

//Lấy thông tin từ Gamebank tại https://sv.gamebank.vn/user/tich-hop-the-cao
$merchant_id = 52513; // interger
$api_user = "5b213600413ee"; // string
$api_password = "8f49876d634ebc8270b661db4700034e"; // string
//Truyền dữ liệu thẻ
$pin = $_POST['pin']; // string
$seri = $_POST['seri']; // string

$price_guest = $_POST['price_guest']; // interger
$card_type = $_POST['card_type_id']; // interger
$ma_bao_mat = $_POST['ma_bao_mat'];
$note = "$iduser - Nạp Tại $_DOMAIN"; //code phát sinh bên web khách hàng

/**
 * Card_type = 1 => Viettel
 * Card_type = 2 => Mobiphone
 * Card_type = 3 => Vinaphone
 * Card_type = 4 => Gate
 * Card_type = 5 => VTC (vcoin)
 * Card_type = 6 => Vietnammobile
 * Card_type = 7 => Zing
 * Card_type = 8 => Bit
 * Card_type = 9 => Megacard
 * Card_type = 10 => Oncash
 
**/

if(isset($_POST['card_auto'])){
    
$return = cardCharging($seri,$pin,$card_type,$price_guest,$note,$merchant_id,$api_user,$api_password);

// nap the thanh cong
if($return['code'] === 0 && $return['info_card'] >= 10000) {
    if($return['info_card'] == 50000){
                    $point = 1;
                }elseif($return['info_card'] == 100000){
                    $point = 2;
                }elseif($return['info_card'] == 200000){
                    $point = 4;
                }elseif($return['info_card'] == 500000){
                    $point = 10;
                }else{
                    $point = 0;
                }  
                
        $now = getdate();
        $tien = $return['info_card']*$ck;
        $db->query("UPDATE accounts SET `cash` = `cash` + '{$tien}' WHERE `username` = '{$iduser}'");// cộng tiền
        $db->query("UPDATE accounts SET `point` = `point` + '{$point}' WHERE `username` = '{$iduser}'");// cộng point
        $db->query("INSERT INTO `history_card` (username,name,type_card,count_card,time,seri,mathe,status) VALUES ('$iduser','$name','$card_type','".$return['info_card']."','$date_current','$seri','$pin','1')");// lịch sử
    
    echo json_encode(array('code' => 0, 'status' => "success",'title' => "Thành công",'msg' => "Nạp thẻ thành công mệnh giá ".$return['info_card'].". Bạn được cộng $tien vào tài khoản"));
}
else {
    // get thong bao loi
    echo json_encode(array('code' => 1, 'status' => "error",'title' => "Lỗi", 'msg' => $return['msg']));
}
}elseif(isset($_POST['card_cham'])){
    $check0 = $db->fetch_row("SELECT COUNT(*) FROM history_card WHERE mathe = '{$pin}' AND seri = '{$seri}' AND count_card = '{$price_guest}' AND type_card = '{$card_type}' AND status = '0'"); //thẻ đang được duyệt
    $check1 = $db->fetch_row("SELECT COUNT(*) FROM history_card WHERE mathe = '{$pin}' AND seri = '{$seri}' AND count_card = '{$price_guest}' AND type_card = '{$card_type}' AND status = '1'"); //thẻ đã sử dụng
    $check2 = $db->fetch_row("SELECT COUNT(*) FROM history_card WHERE mathe = '{$pin}' AND seri = '{$seri}' AND count_card = '{$price_guest}' AND type_card = '{$card_type}' AND status = '2'"); //thẻ sai
    if($check0 > 0){
        echo json_encode(array('code' => '1', 'status' => "error",'title' => "Thất bại",'msg' => "Thẻ đang được chờ duyệt. Vui lòng sử dụng thẻ khác"));exit;}
    if($check1 > 0){
        echo json_encode(array('code' => '1', 'status' => "error",'title' => "Thất bại",'msg' => "Thẻ đã được sử dụng. Vui lòng không thực hiện lại"));exit;}
    if($check2 > 0){
        echo json_encode(array('code' => '1', 'status' => "error",'title' => "Thất bại",'msg' => "Thẻ sai hoặc đã được sử dụng"));exit;}
        
    $db->query("INSERT INTO `history_card` (username,name,type_card,count_card,time,seri,mathe,status) VALUES ('$iduser','$name','$card_type','$price_guest','$date_current','$seri','$pin','0')");// lịch sử
        echo json_encode(array('code' => 0, 'status' => "success",'title' => "Thành công",'msg' => "Gửi yêu cầu thành công. Vui lòng đợi Admin duyệt trong ít phút"));
        
}
}
}

function _isCurl()
{
	return function_exists('curl_version');
}

function cardCharging($seri,$pin,$card_type,$price_guest,$note,$merchant_id,$api_user,$api_password)
{
	if (_isCurl()) {
		$fields = array(
			'merchant_id' => $merchant_id,
			'pin' => $pin,
			'seri' => $seri,
			'price_guest' => $price_guest,
			'card_type' => $card_type,
			'note' => $note
		);
		$ch = curl_init("https://sv.gamebank.vn/api/card");
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
		curl_setopt($ch, CURLOPT_TIMEOUT, 120);
		curl_setopt($ch, CURLOPT_USERPWD, $api_user . ":" . $api_password);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		$result = curl_exec($ch);
		$result = json_decode($result);

		$return = array(
			'code' => $result->code,
			'msg' => $result->msg,
			'info_card' => $result->info_card,
			'transaction_id' => $result->transaction_id,
		);
		
	} else {
		//Trường hợp máy chủ chưa bật cURL
		$result =  file_get_contents("http://sv.gamebank.vn/api/card2?merchant_id=".$merchant_id."&api_user=".trim($api_user)."&api_password=".trim($api_password)."&pin=".trim($pin)."&seri=".trim($seri)."&card_type=".intval($card_type)."&price_guest=".$price_guest."&note=".urlencode($note)."");   
		$result = str_replace("\xEF\xBB\xBF",'',$result); 
		$result = json_decode($result);
		$return = array(
			'code' => $result->code,
			'msg' => $result->msg,
			'info_card' => $result->info_card,
			'transaction_id' => $result->transaction_id,
		);
	}
	return $return;
}