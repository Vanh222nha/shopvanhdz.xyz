<?php
/*
 * 
*/
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user) {
?>
<p class="content-mini content-mini-full bg-warning text-white">Bạn chưa đăng nhập, không thể lấy thông tin</p>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");


$total_record = $db->fetch_row("SELECT COUNT(id) FROM history_transfer WHERE user_nhan = '{$iduser}' or user_gui = '{$iduser}' LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "10",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_transfer = "SELECT * FROM `history_transfer` WHERE user_nhan = '{$iduser}' or user_gui = '{$iduser}' ORDER BY `time` DESC LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Thông tin</th>
                                    <th>Nội dung</th>
                                    <th>Thời gian</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_transfer, 0) as $key => $data_transfer){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td>
                                    <?php    
                                    if($data_transfer['user_nhan'] == $iduser){
                                      echo "Nhận <font color='red'>".number_format($data_transfer['cash'], 0, '.', '.')."đ</font> từ <font color='yellow'>".$data_transfer['user_gui']."</font>";
                                    }elseif($data_transfer['user_gui'] == $iduser){
                                        echo "Chuyển <font color='red'>".number_format($data_transfer['cash'], 0, '.', '.')."đ</font> cho <font color='yellow'>".$data_transfer['user_nhan']."</font>";
                                    }    
                                    ?>    
                                    </td>
                                    <td><?php echo $data_transfer['note']; ?></td>
                                    <td><?php echo $data_transfer['time']; ?></td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                        </div>
                    
<?php                     
echo $paging->html_transfer(); // page
}else {
?>
<p class="content-mini content-mini-full bg-info text-white">Bạn chưa có giao dịch nào</p>
<?php
}
?>




