<?php
/*

 * Chuc nang: lưu dữ liệu trang web
 */
 
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
// Nếu đăng nhập
if ($user && $data_user['admin'] > 0) 
{   $thongbao = trim(htmlspecialchars(addslashes($_POST['thongbao'])));
    $title_web = trim(htmlspecialchars(addslashes($_POST['title'])));
    $descr_web = trim(htmlspecialchars(addslashes($_POST['descr'])));
    $keywords_web = trim(htmlspecialchars(addslashes($_POST['keywords'])));
    $status = trim(htmlspecialchars(addslashes($_POST['status'])));
    $name_admin = trim(htmlspecialchars(addslashes($_POST['name_admin'])));
    $fb_admin = trim(htmlspecialchars(addslashes($_POST['fb_admin'])));
    $fanpage = trim(htmlspecialchars(addslashes($_POST['fanpage'])));
    $phone_admin = trim(htmlspecialchars(addslashes($_POST['phone_admin'])));
    $video_home = trim(htmlspecialchars(addslashes($_POST['video_home'])));
    $phone_admin = trim(htmlspecialchars(addslashes($_POST['phone_admin'])));
    $video_guide = trim(htmlspecialchars(addslashes($_POST['video_guide'])));
    $ck = 100 - $_POST['ck'];
    $ckc_viettel = 100 - $_POST['ckc_viettel'];
    $ckc_vina = 100 - $_POST['ckc_vina'];
    $ckc_mobi = 100 - $_POST['ckc_mobi'];
    $ckc_gate = 100 - $_POST['ckc_gate'];
    $ckc_zing = 100 - $_POST['ckc_zing'];
    $ckc_vcoin = 100 - $_POST['ckc_vcoin'];
    $ck_card = 100 - $_POST['ck_card'];
    $price_rd = $_POST['price_rd'];


    $db->query("UPDATE `posts` SET
        `price`='$price_rd'
        WHERE `type_account`='rd_lq' OR `type_account` = 'rd_lol' ");
    $sql_info_web = "UPDATE settings SET 
        thongbao = '$thongbao',
        title = '$title_web',
        descr = '$descr_web',
        keywords = '$keywords_web',
        name_admin = '$name_admin',
        fb_admin = '$fb_admin',
        fanpage = '$fanpage',
        phone_admin = '$phone_admin',
        video_home = '$video_home',
        video_guide = '$video_guide',
        status= '$status',
        ck = '$ck',
        ckc_viettel = '$ckc_viettel',
        ckc_vina = '$ckc_vina',
        ckc_mobi = '$ckc_mobi',
        ckc_gate = '$ckc_gate',
        ckc_zing = '$ckc_zing',
        ckc_vcoin = '$ckc_vcoin',
        price_rd = '$price_rd',
        ck_card = '$ck_card'
    ";
    $db->query($sql_info_web);
    $db->close();
    echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => "Lưu cài đặt thành công"));
}
else {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập hoặc không phải là Admin"));
}
?>