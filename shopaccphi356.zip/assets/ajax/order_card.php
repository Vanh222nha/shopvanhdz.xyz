<?php
session_start();
error_reporting(E_ALL^E_NOTICE);
error_reporting(E_ERROR);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
$ck_card = $data_site['ck_card']*0.01;
if (!$user) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    $type_card = $_POST['type_card'];  
    $count_card = $_POST['count_card'];
    $note = $_POST['note'];
    $password = md5(md5($_POST['password']));
    $cash = $count_card*$ck_card;
    if(empty($password)){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Vui lòng nhập mật khẩu !"));exit;}
    if($data_user['cash'] < $cash){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Số dư không đủ để thực hiện giao dịch !"));exit;}
    if($password != $data_user['password']){
        echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Mật khẩu không chính xác"));exit;}
    
    $db->query("UPDATE accounts SET `cash` = `cash` - '{$cash}' WHERE `username` = '{$iduser}'");// trừ tiền 
    $db->query("INSERT INTO `order_card` (username,type_card,count_card,note,status,date) VALUES ('$iduser','$type_card','$count_card','$note','0','$date_current')");// lịch sử    
    echo json_encode(array('code' => 0, 'status' => "success",'title' => "Thành công",'msg' => "Gửi yêu cầu thành công. Vui lòng đợi Admin xử lý."));
}