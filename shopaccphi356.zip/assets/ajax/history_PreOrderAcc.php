<?php
/*

 */
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user) {
?>
<p class="content-mini content-mini-full bg-warning text-white">Bạn chưa đăng nhập, không thể lấy thông tin</p>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");


$total_record = $db->fetch_row("SELECT COUNT(id) FROM pre_order WHERE username = '{$iduser}' AND status = '0' LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "10",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_buy = "SELECT * FROM `pre_order` WHERE username = '{$iduser}' AND status = '0' ORDER BY `time` DESC LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Tên</th>
									<th>Đã cọc</th>
                                    <th>Thời Hạn</th>
                                    <th>Ngày đặt cọc</th>
									<th>Thanh Toán</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_buy, 0) as $key => $data_buy){ 
    $info = $db->fetch_assoc("SELECT * FROM pre_order LIMIT 1", 1); 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td>#<?php echo $data_buy['id_post']; ?></td>
                                    <td><?php echo number_format($data_buy['price'], 0, '.', '.'); ?><sup>đ</sup></td>
                                    <td><?php echo $data_buy['days']; ?>  Ngày </td>
									<td><?php echo $data_buy['date']; ?></td>
									<td>
									<p class="sl-prbot"><a href="<?php echo $data_buy['id_post']; ?>.html" title="MUA NGAY" class="sl-btnod" >Thanh Toán</a></p>
									</td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_buy(); // page
}else {
?>
<p class="content-mini content-mini-full bg-info text-white">Bạn chưa có giao dịch nào</p>
<?php
}
?>