<?php
/*
 */
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$get_info_card = new Info;
if (!$user && $data_user['admin'] < 1) {
?>
<p class="content-mini content-mini-full bg-warning text-white">Bạn chưa đăng nhập, không thể lấy thông tin</p>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");
$username = $input->input_post("username");

if (!empty($username)) {
$sql_username = "AND username LIKE '%$username%'";
}
$total_record = $db->fetch_row("SELECT COUNT(id) FROM history_card WHERE status = '0' $sql_username LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_mem = "SELECT * FROM `history_card` WHERE status = '0' $sql_username ORDER BY `status` ASC, `time` ASC  LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Tên</th>
                                    <th>Loại thẻ</th>
                                    <th>Trạng Thái</th>
                                    <th>Time</th>
                                    <th class="text-center" style="width: 100px;">Thao tác</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td><?php echo $data['username']; ?></td>
                                    <td><?php echo $get_info_card->get_string_card($data["type_card"]); ?>/<?php echo $data['count_card']/1000; ?>K</td>
                                    <td><?php echo $data['date']; ?><?php echo $get_info_card->get_string_status_card($data["status"]); ?></td>
                                    <td><?php echo $data['time']; ?></td>
                                    <td class="text-center">
                                    <div class="btn-group"><a href="?act=edit_card&id=<?php echo $data['id']; ?>" target="_blank">
                                    <button class="btn btn-xs btn-default" type="button" data-toggle="tooltip" title="Sửa người dùng">Xem</button>
                                    </a></div>
                                    </td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_member(); // page
}else {
?>
<p class="content-mini content-mini-full bg-info text-white">Không có yêu cầu nào</p>
<?php
}
?>




