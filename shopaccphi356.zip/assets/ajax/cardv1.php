<?php
error_reporting(0);
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
$iduser = $data_user['username'];
$name = addslashes($data_user['name']);
        $to 		= "danghaild@gmail.com"; // mail gửi đến
        $subject	= 'Khách Nạp Thẻ' ; // tiêu đề mail
        $message   	= "'<h3>Tên: $name <br/>
                       Loại Thẻ : $card_type <br/>
                       Mệnh Giá : $menhgia <br/>
        </h3>'"; // nội dung gửi
        $header		= "From: danghaild@gmail.com.vn \r\n"; 	// chân form mail
        $header		.= "Content-type: text/html; charset=utf-8 \r\n"; 
if (!$user) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Bạn chưa đăng nhập"));
} else {
    
    if (!$_POST['type']) {
    echo json_encode(array('status' => "error", 'title' => "Lỗi", 'msg' => "Chưa chọn loại nhà mạng"));
    }else{
	    
    if(mail ($to, $subject, $message, $header)==true){
        $menhgia  = $_POST['menhgia'];
        $card_type  = $_POST['type'];
        $pin = ($_POST['code']);
        $seri  =($_POST['serial']);
        $now = getdate();
        $db->query("INSERT INTO `history_card` (username,name,type_card,mathe,seri,status,count_card,time) VALUES ('$iduser','$name','$card_type',$pin,$seri,'0','$menhgia','$date_current')");// lịch sử
            
        echo json_encode(array('status' => "success", 'title' => "Thành công", 'msg' => $charge->message));

    }else{
        echo json_encode(array('status' => "error", 'title' => "Thất Bại", 'msg' => $charge->message));
    };
}
}
?>