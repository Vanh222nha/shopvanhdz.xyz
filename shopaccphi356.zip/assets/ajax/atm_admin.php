<?php
/*
 */
// Kết nối database và thông tin chung
require_once(realpath($_SERVER["DOCUMENT_ROOT"]) .'/core/init.php');
if (!$user && $data_user['admin'] < 1) {
?>
<p class="content-mini content-mini-full bg-warning text-white">Bạn chưa đăng nhập, không thể lấy thông tin</p>
<?php
exit;
}elseif(!$_POST){
exit;
}

$iduser = $data_user['username'];
$input = new Input;
$page = (int)$input->input_post("page");
$username = $input->input_post("username");
$idus = $input->input_post("idus");

if (!empty($username)) {
$sql_username = "AND username LIKE '%$username%'";
}
$total_record = $db->fetch_row("SELECT COUNT(id) FROM history_atm WHERE status = '0' $sql_username LIMIT 1");
    // config phân trang
    $config = array(
      "current_page" => $page,
      "total_record" => $total_record,
      "limit" => "20",
      "range" => "5",
      "link_first" => "",
      "link_full" => "?page={page}"
    );
    
    $paging = new Pagination;
    $paging->init($config);
    $sql_get_list_mem = "SELECT * FROM `history_atm` WHERE status = '0' $sql_username ORDER BY `status` ASC, `date` ASC  LIMIT {$paging->getConfig()["start"]}, {$paging->getConfig()["limit"]}";

// Nếu có 
if ($total_record){
?>
                        <table  class="table table-bordered">
                             <thead><tr>
                                    <th class="text-center" style="width: 50px;">#</th>
                                    <th>Tên</th>
                                    <th>Tiền</th>
                                    <th>Trạng Thái</th>
                                    <th>Time</th>
                                    <th class="text-center" style="width: 100px;">Thao tác</th>
                                </tr></thead>
                        <tbody>
<?php                            
$i=1;
foreach ($db->fetch_assoc($sql_get_list_mem, 0) as $key => $data){ 
?>


                             <tr>
                                    <td class="text-center"><?php echo $i; ?></td>
                                    <td><a target="_blank" style="<?php echo($data['admin']=='1') ? "color: red;font-weight: bold;":""; ?>"><?php echo $data['username']; ?></a></td>
                                    <td><?php echo number_format($data['cash_nhan'], 0, '.', '.'); ?><sup>vnđ</sup></td>
                                    <td>
                                    <?php
                                        if($data['status'] == "0"){
                                            echo '<font color="gray">Đang xử lý</font>';
                                        }elseif($data['status'] == "1"){
                                            echo '<font color="green">Hoàn thành</font>';
                                        }elseif($data['status'] == "2"){
                                            echo '<font color="yellow">Không thành công. Đã hoàn tiền</font>';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $data['date']; ?></td>
                                    <td class="text-center">
                                    <div class="btn-group"><a href="?act=bank&id=<?php echo $data['id']; ?>" target="_blank">
                                    <button class="btn btn-xs btn-default" type="button" data-toggle="tooltip" title="Sửa người dùng">Xem</button>
                                    </a></div>
                                    </td>
                            </tr>



<?php 
$i++;
}
?>
                        </tbody>
                        
                        </table>
                    
<?php                     
echo $paging->html_member(); // page
}else {
?>
<p class="content-mini content-mini-full bg-info text-white">Không có yêu cầu nào</p>
<?php
}
?>




