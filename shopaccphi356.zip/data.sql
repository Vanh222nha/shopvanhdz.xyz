DROP TABLE `acc_random`;

CREATE TABLE `acc_random` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;




DROP TABLE `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `taikhoan` varchar(100) CHARACTER SET utf8 NOT NULL,
  `password` varchar(100) CHARACTER SET utf8 NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  `block` int(1) NOT NULL,
  `note` text COLLATE utf8_unicode_ci NOT NULL,
  `admin` int(1) NOT NULL,
  `time` datetime NOT NULL,
  `phone` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `accounts` VALUES("0","","","","","","0","0","0","","0","0000-00-00 00:00:00","");
INSERT INTO `accounts` VALUES("3","hdan","hdan","63ee451939ed580ef3c4b6f0109d1fd0","đạia","dakdna@gmail.com","10000","0","0","","0","2018-08-23 14:44:59","0da2311");
INSERT INTO `accounts` VALUES("6","hackerahihi","hackerahihi","4d447396a8a805d5da0183857170be87","minhphi","minhphi365.com@gmail.com","0","0","0","","0","2018-08-27 20:30:46","01285379628");
INSERT INTO `accounts` VALUES("7","minhphi","minhphi","8f422091bffd45806bfa2e8a1d218eb0","minhphi","minhphi365.cogm@gmail.com","11000","0","0","","0","2018-08-27 23:22:19","09370721812");
INSERT INTO `accounts` VALUES("9","523321694754691","523321694754691","3ea4e9abb76947edbabef288efe3bd76","Trương Nguyễn Kim Hùng","kimhungtruongnguyen@gmail.com","255000","9910","0","","1","2018-08-28 15:41:25","0905593433");
INSERT INTO `accounts` VALUES("10","hungproh5n","hungproh5n","3ea4e9abb76947edbabef288efe3bd76","Trương Nguyễn Kim Hùng","cherrykrixi@gmail.com","96000","2","0","","0","2018-08-28 19:37:06","0935100048");
INSERT INTO `accounts` VALUES("11","anhanh","anhanh","e036c41e8785a4be52a3e52759489772","anhanh","anhjs@gmail.com","0","0","1","Tài khoản giả mạo","0","2018-08-28 23:27:42","012492994939");
INSERT INTO `accounts` VALUES("12","404318560095037","404318560095037","","Phạm Thành Tư Hản","","0","0","0","","0","2018-08-30 17:19:59","");
INSERT INTO `accounts` VALUES("13","afafafafa","afafafafa","df2ac1b08b98301953e6efe6fa49dd8b","Ngô Đức Hưng","nexodust1111@gmail.com","0","0","0","","0","2018-08-30 20:46:14","1233184316");



DROP TABLE `history_atm`;

CREATE TABLE `history_atm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) NOT NULL,
  `cash_nhan` int(11) NOT NULL,
  `nganhang` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chinhanh` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `chutk` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sotk` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `status` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `history_atm` VALUES("10","hackerahihi","500000","490000","BACABANK","fsdfdsffF","FSDAFSDAF","8945341851051","SDRFSD","2018-07-19 14:13:13","2");
INSERT INTO `history_atm` VALUES("9","luauytin","100000","90000","VIETCOMBANK","Đà Nẵng","Điệp Nguyễn Tuấn","457456345354","test","2018-07-18 22:16:43","2");
INSERT INTO `history_atm` VALUES("7","tuandiep","100000","55000","VIETTINBANK","Jđi","733838","Sjshsksji","","2018-07-15 20:19:25","1");
INSERT INTO `history_atm` VALUES("8","hackerahihi","500000","275000","VIETCOMBANK","Long An","MInh Phi","54216541205350","test","2018-07-17 09:52:50","2");
INSERT INTO `history_atm` VALUES("6","luauytin","100000","55000","AGRIBANK","Đà Nẵng","Điệp Nguyễn Tuấn","457456345354","","2018-07-15 20:15:38","2");
INSERT INTO `history_atm` VALUES("11","hackerahihi","500000","490000","VIETCOMBANK","Long.an  ","Minh Phi","7392729482223","Tnjj","2018-07-19 19:28:59","1");
INSERT INTO `history_atm` VALUES("12","nqhuytptq","50000","40000","MBBANK","HA NOI","NGUYEN QUANG HUY","5485660095572966","nhanh giùm, đang cần gấp","2018-08-12 15:37:07","2");
INSERT INTO `history_atm` VALUES("13","523321694754691","25000000","24990000","TECHCOMBANK","Đà Nẵng - Thhanh khê","Trương Thị Diệu Huyền","10000523662058","rút tiền","2018-08-28 10:22:49","2");
INSERT INTO `history_atm` VALUES("14","523321694754691","100000","90000","SEABANK","Thanh khê - Đà nẵng","Trương Thị Diệu Huyền","100025611588","rút tiền","2018-08-28 15:19:41","1");



DROP TABLE `history_buy`;

CREATE TABLE `history_buy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `loaiacc` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `id_post` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `history_buy` VALUES("1","523321694754691","Trương Nguyễn Kim Hùng","Code Website","9","10000","2018-08-28 15:44:53");
INSERT INTO `history_buy` VALUES("2","minhphi","minhphi","Code Website","11","25000","2018-08-28 23:13:17");
INSERT INTO `history_buy` VALUES("3","minhphi","minhphi","Code Website","10","12000","2018-08-29 07:09:39");
INSERT INTO `history_buy` VALUES("4","hungproh5n","Trương Nguyễn Kim Hùng","Code Website","11","25000","2018-08-29 10:35:03");
INSERT INTO `history_buy` VALUES("5","523321694754691","Trương Nguyễn Kim Hùng","Code Website","11","25000","2018-08-29 14:47:58");
INSERT INTO `history_buy` VALUES("6","minhphi","minhphi","Code Website","10","12000","2018-08-30 21:21:13");
INSERT INTO `history_buy` VALUES("7","minhphi","minhphi","Code Website","12","40000","2018-09-01 09:17:45");



DROP TABLE `history_card`;

CREATE TABLE `history_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type_card` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `mathe` text COLLATE utf8_unicode_ci NOT NULL,
  `seri` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `count_card` int(11) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `history_card` VALUES("1","523321694754691","Trương Nguyễn Kim Hùng","4","6275274431","CA00416744","1","10000","2018-08-28 15:44:13");
INSERT INTO `history_card` VALUES("2","523321694754691","Trương Nguyễn Kim Hùng","2","1231222213213","12321321123132","4","500000","2018-08-28 16:40:03");
INSERT INTO `history_card` VALUES("3","523321694754691","Trương Nguyễn Kim Hùng","2","1231222213213","12321321123132","2","1000000","2018-08-28 16:40:14");
INSERT INTO `history_card` VALUES("4","hungproh5n","Trương Nguyễn Kim Hùng","4","3177248420","CA00415532","2","10000","2018-08-29 10:09:22");
INSERT INTO `history_card` VALUES("5","hungproh5n","Trương Nguyễn Kim Hùng","4","3177248420","CA00415532","1","1000000","2018-08-29 10:12:25");
INSERT INTO `history_card` VALUES("6","hungproh5n","Trương Nguyễn Kim Hùng","4","2166587078","CA00416727","1","10000","2018-08-29 10:33:53");
INSERT INTO `history_card` VALUES("7","523321694754691","Trương Nguyễn Kim Hùng","2","10254059650","102510000041685","1","10000","2018-08-29 10:54:44");
INSERT INTO `history_card` VALUES("8","523321694754691","Trương Nguyễn Kim Hùng","4","7510441447","CA00405083","1","10000","2018-08-30 09:07:35");
INSERT INTO `history_card` VALUES("9","523321694754691","Trương Nguyễn Kim Hùng","2","1231222213213","12321321123132","2","10000","2018-08-30 09:10:18");
INSERT INTO `history_card` VALUES("10","523321694754691","Trương Nguyễn Kim Hùng","4","1610678005","cb02358543","1","20000","2018-08-30 12:58:41");
INSERT INTO `history_card` VALUES("11","523321694754691","Trương Nguyễn Kim Hùng","4","5141066632","CB02358557","1","20000","2018-08-30 16:28:02");
INSERT INTO `history_card` VALUES("12","523321694754691","Trương Nguyễn Kim Hùng","4","5141066632","CB02358557","1","20000","2018-08-30 16:28:14");
INSERT INTO `history_card` VALUES("13","404318560095037","Phạm Thành Tư Hản","1","414197247386397","10001452435997","2","20000","2018-08-30 17:24:57");
INSERT INTO `history_card` VALUES("14","404318560095037","Phạm Thành Tư Hản","1","414197247386397","10001452435996","2","20000","2018-08-30 18:10:56");
INSERT INTO `history_card` VALUES("15","523321694754691","Trương Nguyễn Kim Hùng","1","123123121","123123123","2","0","2018-08-31 10:47:02");
INSERT INTO `history_card` VALUES("16","523321694754691","Trương Nguyễn Kim Hùng","1","13121231320","1212331200","2","2147483647","2018-08-31 10:50:23");
INSERT INTO `history_card` VALUES("17","523321694754691","Trương Nguyễn Kim Hùng","1","12312","231123132","3","0","2018-08-31 10:57:45");
INSERT INTO `history_card` VALUES("18","hungproh5n","Trương Nguyễn Kim Hùng","1","4644478261151","68690913986","1","50000","2018-09-02 10:34:51");
INSERT INTO `history_card` VALUES("19","hungproh5n","Trương Nguyễn Kim Hùng","1","112915714209081","10001249722555","1","50000","2018-09-02 12:09:03");



DROP TABLE `history_transfer`;

CREATE TABLE `history_transfer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_nhan` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `user_gui` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cash` int(11) NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;




DROP TABLE `order_card`;

CREATE TABLE `order_card` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type_card` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `count_card` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `seri` text NOT NULL,
  `pin` text NOT NULL,
  `status` int(11) NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `order_card` VALUES("1","minhphi","1","10000","","","3","","2018-08-28 23:53:06");
INSERT INTO `order_card` VALUES("2","523321694754691","5","100000","","","2","","2018-08-29 18:31:53");
INSERT INTO `order_card` VALUES("3","hungproh5n","1","20000","10001452435997","414197247386397","1","Em cần mua thẻ gấp ad ơi!!!","2018-08-30 16:58:44");
INSERT INTO `order_card` VALUES("4","hungproh5n","1","5000","","","0","dsadsa","2018-09-01 12:46:47");
INSERT INTO `order_card` VALUES("5","hungproh5n","1","10000","","","0","12321121231","2018-09-01 15:15:18");



DROP TABLE `posts`;

CREATE TABLE `posts` (
  `id_post` int(11) NOT NULL AUTO_INCREMENT,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `price` text COLLATE utf8_unicode_ci NOT NULL,
  `price_atm` text COLLATE utf8_unicode_ci NOT NULL,
  `chbm` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `cmnd` text COLLATE utf8_unicode_ci NOT NULL,
  `gem_count` int(11) NOT NULL,
  `skins_count` int(11) NOT NULL,
  `skins` longtext COLLATE utf8_unicode_ci NOT NULL,
  `champs_count` int(11) NOT NULL,
  `champs` longtext COLLATE utf8_unicode_ci NOT NULL,
  `rank` int(11) NOT NULL,
  `frame` int(11) NOT NULL,
  `ip_count` int(11) NOT NULL,
  `ff_exp` longtext COLLATE utf8_unicode_ci NOT NULL,
  `ff_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `note` longtext COLLATE utf8_unicode_ci NOT NULL,
  `type_post` int(11) NOT NULL,
  `type_account` text COLLATE utf8_unicode_ci NOT NULL,
  `date_posted` datetime NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_post`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `posts` VALUES("1","awmkfam","3Sdkoama","25000","25000","","nguybac112004@gmail.com","","0","0","","0","","0","0","0","","","Bạc:13.081.307\nVàng:148\nDanh vọng:5.591\nHạng đấu trường: 5\nLv:49","1","PokemonZ","2018-08-22 21:15:21","1");
INSERT INTO `posts` VALUES("3","hotboypro1","d2aSiaww11","34000","34000","","batuoc1252071@gmail.com","","0","0","","0","","0","0","0","","","Bạc:4.622.707\nVàng:16.628\nDanh vọng:819\nHạng đấu trường: 11\nLv:42","1","PokemonZ","2018-08-23 14:38:19","0");
INSERT INTO `posts` VALUES("4","thai2007","nguyenhung1727","11000","","","nguyenhung1272004@gmail.com","","0","0","","0","","0","0","0","","","Bạc:8.820.956\nVàng:14\nDanh vọng:394\nHạng đấu trường: 15\nLv:47","3","PokemonZ","2018-08-25 10:33:56","0");
INSERT INTO `posts` VALUES("5","123123123","12321312","","","","","","0","0","","0","","0","0","0","","","","0","rd_pokemon","2018-08-25 10:38:19","1");
INSERT INTO `posts` VALUES("6","headdanang","đậm","150000","","","trống","","0","0","","0","","0","0","0","","","","2","Code Website","2018-08-27 08:29:37","1");
INSERT INTO `posts` VALUES("8","kimhung365.com/a1w4Sq.zip","trong code","150000","120000","","trống","","0","0","","0","","0","0","0","","","--&amp;gtCode Web bán acc game tự động vip\n--&amp;gtConfig data + thông tin: classes/DB.php | core/ init.php\n--&amp;gtCode có chức năng hay:vòng quay,đăng nhập bằng 3 đường,nạp thẻ tích hợp qua Gamebank.vn\n--&amp;gtConfig tích hơp: assets/ajax/card.php\n--&amp;gtNhận làm sau khi mua code","2","Code Website","2018-08-27 09:15:05","0");
INSERT INTO `posts` VALUES("9","drive.google.com/file/d/0B3Vv7rMUkXwUcDg4T19BanZ1ZjA/view","trong code","10000","","","sharecode.vn (nếu có)","","0","0","","0","","0","0","0","","","--&amp;gtCài đặt rất đơn giản. Bạn có thể tải lên tất cả các tệp trên máy chủ lưu trữ hoặc máy chủ cục bộ đã chạy xong\n--&amp;gtLàm theo sau ten-web-cua-ban.com/installer.php và làm theo hướng dẫn.\n--&amp;gtNếu bạn không cài được thì liên hệ cho mình\n--&amp;gtACOUNT: admin\n--&amp;gtMật khẩu: admin @ #\n--&amp;gtClip để xem hưỡng dẫn cài đặt: https://www.youtube.com/embed/jTRy1eN5aMI\n--&amp;gtlink demo:123website.com.vn/demo/?template_id=8651","3","Code Website","2018-08-28 09:51:30","0");
INSERT INTO `posts` VALUES("10","megaurl.in/WGQm72","trong code","12000","","","trống","","0","0","","0","","0","0","0","","","&amp;lt&amp;gtCode web bán acc game tự động&amp;lt&amp;gt\n&amp;lt&amp;gtConfig: dantranhethong/config.php&amp;lt&amp;gt\n&amp;lt&amp;gtCòn vài chỗ để sửa&amp;lt&amp;gt\n&amp;lt&amp;gtNhận làm sau khi mua&amp;lt&amp;gt\n&amp;lt&amp;gtCode này đã được nhiều bạn share,nhưng toàn lỗi,và mình đã fix tất cả&amp;lt&amp;gt","1","Code Website","2018-08-28 17:27:08","0");
INSERT INTO `posts` VALUES("11","megaurl.in/FbKU0","megaurl.in/UWchZXU","25000","","","trống","","1","0","","0","","0","0","0","","","&amp;amplt&amp;ampgtCode Web bán acc game tự động&amp;amplt&amp;ampgt\nHướng dẫn cài đặt code\nConfig tại core/database.php và core/fbconfig.php.\nCode đã được fix lỗi login facebook + nạp chậm\n&amp;amplt&amp;ampgtHỗ trợ làm khi mua&amp;amplt&amp;ampgt","1","Code Website","2018-08-28 17:33:27","0");
INSERT INTO `posts` VALUES("12","drive.google.com/file/d/1myOHiHWhqApAiqFs8KHc52Ulkdf5Zz5V/view","trống","40000","","","trống","","0","0","","0","","0","0","0","","","Code web game pokemon thẻ bài\n&amp;gtCode khá đẹp\n&amp;gtconfig tại : system/data_base.php\n&amp;gthỗ trợ làm khi mua","1","Code Website","2018-08-31 11:14:22","0");



DROP TABLE `pre_order`;

CREATE TABLE `pre_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `id_post` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




DROP TABLE `settings`;

CREATE TABLE `settings` (
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `thongbao` text COLLATE utf8_unicode_ci NOT NULL,
  `descr` longtext COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `fanpage` text COLLATE utf8_unicode_ci NOT NULL,
  `fb_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `name_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `phone_admin` text COLLATE utf8_unicode_ci NOT NULL,
  `video_home` text COLLATE utf8_unicode_ci NOT NULL,
  `video_guide` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `ck` int(11) NOT NULL,
  `ckc_viettel` int(11) NOT NULL,
  `ckc_vina` int(11) NOT NULL,
  `ckc_mobi` int(11) NOT NULL,
  `ckc_zing` int(11) NOT NULL,
  `ckc_gate` int(11) NOT NULL,
  `ckc_vcoin` int(11) NOT NULL,
  `price_rd` int(11) NOT NULL,
  `ck_card` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `settings` VALUES("Mua bán Code web , Nhận đổi thẻ cào sang tiền mặt chiết khẩu thấp.","Hiện web game Pokemonz đã chuyển sang địa chỉ mới, đó là pokemonz.ml còn địa chỉ kimhung365.com sẽ bán code web nhé,cảm ơn các bạn","","Shop lq, acc liên quân, bán acc liên quân, mua acc liên quân, shop acc liên quân, ban acc liên quân, shop liên quân, mua nick liên quân, shop acc lien quan, mua nick lien quan , đổi thẻ cào sang tiền mặt uy tính , doi the cao sang tien mat uy tinh , doi the cao sang tien mat , doi the cao sang tien , đổi thẻ cào sang tiền mặt,shop bán acc Pokemonz, shop pokemon, kimhungshop, giaodienweb, khogiaodien.net","https://www.facebook.com/kimhungmcpe","https://www.facebook.com/kimhungmcpe","Trương Nguyễn Kim Hùng","09351.000.48","https://www.youtube.com/embed/jZQ0gd9XAEQ?ecver=2&amp;ampampampampampautoplay=1","https://www.youtube.com/embed/RK8xI9qkx8","1","96","55","55","100","0","0","98","10000","100");



DROP TABLE `wheel_acc`;

CREATE TABLE `wheel_acc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `pass` longtext COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wheel_acc` VALUES("3","Thẻ vcoin 20.000Đ"," Số seri: ID0356921576  Mã nạp: 862453328709","1","1535514030");
INSERT INTO `wheel_acc` VALUES("4","Acc truy kích (có bảo mật)","TK:conquaden00 MK:cherrykrixi@gmail.com","1","1535514141");
INSERT INTO `wheel_acc` VALUES("6","Acc pokemonz (chơi game pokemonz.ml)","TK:sam12345  |   MK:trungvip123  |  EMail đổi mk:huy163364@gmail.com","1","1535514395");
INSERT INTO `wheel_acc` VALUES("7","Acc pokemonz (chơi game pokemonz.ml)","TK:hotboypre1 | MK:ldmaws | EMail đổi mk:batuoc12339599@gmail.com","1","1535514481");



DROP TABLE `wheel_history`;

CREATE TABLE `wheel_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fb` text COLLATE utf8_unicode_ci NOT NULL,
  `text` longtext COLLATE utf8_unicode_ci NOT NULL,
  `text_us` longtext COLLATE utf8_unicode_ci NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `wheel_history` VALUES("1","hungproh5n","Nhận được 10.000 VNĐ","Nhận được 100.000 VNĐ","1535512379");
INSERT INTO `wheel_history` VALUES("2","523321694754691","Nhận được 10.000 VNĐ","Nhận được 20.000 VNĐ","1535513929");
INSERT INTO `wheel_history` VALUES("3","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535513948");
INSERT INTO `wheel_history` VALUES("4","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535514039");
INSERT INTO `wheel_history` VALUES("5","523321694754691","Nhận được Hộp quà bí mật","Hộp quà bí mật bạn nhận được là Thẻ vcoin 20.000Đ /  Số seri: ID0356921576  Mã nạp: 862453328709","1535514050");
INSERT INTO `wheel_history` VALUES("6","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535514495");
INSERT INTO `wheel_history` VALUES("7","523321694754691","Nhận được Hộp quà bí mật","Hộp quà bí mật bạn nhận được là Acc truy kích (có bảo mật) / TK:conquaden00 MK:cherrykrixi@gmail.com","1535514516");
INSERT INTO `wheel_history` VALUES("8","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535514547");
INSERT INTO `wheel_history` VALUES("9","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535514645");
INSERT INTO `wheel_history` VALUES("10","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535514653");
INSERT INTO `wheel_history` VALUES("11","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535514799");
INSERT INTO `wheel_history` VALUES("12","523321694754691","Nhận được Hộp quà bí mật","Hộp quà bí mật bạn nhận được là Acc pokemonz (chơi game pokemonz.ml) / TK:hotboypre1 | MK:ldmaws | EMail đổi mk:batuoc12339599@gmail.com","1535544162");
INSERT INTO `wheel_history` VALUES("13","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535594926");
INSERT INTO `wheel_history` VALUES("14","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535595186");
INSERT INTO `wheel_history` VALUES("15","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535595196");
INSERT INTO `wheel_history` VALUES("16","523321694754691","Nhận được Hộp quà bí mật","Hộp quà bí mật bạn nhận được là Acc pokemonz (chơi game pokemonz.ml) / TK:sam12345  |   MK:trungvip123  |  EMail đổi mk:huy163364@gmail.com","1535595223");
INSERT INTO `wheel_history` VALUES("17","523321694754691","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535596454");
INSERT INTO `wheel_history` VALUES("18","hungproh5n","Nhận được 10.000 VNĐ","Nhận được 10.000 VNĐ","1535782728");



