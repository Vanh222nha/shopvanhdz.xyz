<?php
//exit('Bao tri');

 
// Require database & th??ng tin chung
require_once 'core/init.php';
 
// Require header
require_once 'includes/header.php';
// Danh sach account

$xss = new Anti_xss;

$act = $xss->clean_up($_GET['act']);

switch ($act) {
	case 'view':
		require_once 'templates/products/view.php'; 
		break;

	case 'LMHT':
		require_once 'templates/products/lol_list.php'; 
		break;
		
	case 'LQM':
		require_once 'templates/products/lqm_list.php'; 
		break;
	case 'random':
		require_once 'templates/products/rd_list.php'; 
		break;
	default:
		require_once 'templates/products/lol_list.php'; 
		break;
}


// Require footer
require_once 'includes/footer.php';
 
?>