<?php
// Require database 
require_once 'core/init.php';
 if(!$user){header('Location: /');}
// Require header
require_once 'includes/header.php';
// Danh sach
require_once 'assets/ajax/main.php';
require_once 'templates/order_card.php'; 
// Require footer
require_once 'includes/footer.php';
 
?>