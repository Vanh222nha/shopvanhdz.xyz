<?php
// Require database 
require_once 'core/init.php';
 
// Require header
require_once 'includes/header.php';
// Danh sach account
require_once 'templates/wheel.php'; 
// Require footer
require_once 'includes/footer.php';
 
?>